# MORRE Flutter Phase 2
تمت إضافة ربط أسعار العملات بـ Cloud Firestore.
الـ collection الافتراضي: currencies
الحقول المدعومة: code, nameAr/name, flag, official.buy/sell, parallel.buy/sell, changePercent.
قبل التشغيل: flutter pub get ثم flutterfire configure ثم flutter run.
