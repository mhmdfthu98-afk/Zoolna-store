import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  NotificationService._();

  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  bool _ready = false;

  Future<void> initialize() async {
    if (_ready) return;

    const initializationSettings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    );

    await _plugin.initialize(
      settings: initializationSettings,
    );

    const channel = AndroidNotificationChannel(
      'morre_price_alerts',
      'تنبيهات الأسعار',
      description: 'تنبيهات تغير أسعار العملات',
      importance: Importance.high,
    );

    final androidPlugin = _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    await androidPlugin?.createNotificationChannel(channel);

    _ready = true;
  }

  Future<void> showPriceAlert({
    required String title,
    required String body,
  }) async {
    await initialize();

    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'morre_price_alerts',
        'تنبيهات الأسعار',
        channelDescription: 'تنبيهات تغير أسعار العملات',
        importance: Importance.high,
        priority: Priority.high,
      ),
    );

    await _plugin.show(
      id: DateTime.now().microsecondsSinceEpoch.remainder(2147483647),
      title: title,
      body: body,
      notificationDetails: details,
    );
  }
}