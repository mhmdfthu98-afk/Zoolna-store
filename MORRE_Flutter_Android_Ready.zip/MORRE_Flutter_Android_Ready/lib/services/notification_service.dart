import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  NotificationService._();
  static final instance = NotificationService._();

  final _plugin = FlutterLocalNotificationsPlugin();
  bool _ready = false;

  Future<void> initialize() async {
    if (_ready) return;
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: android));
    const channel = AndroidNotificationChannel(
      'morre_price_alerts',
      'تنبيهات الأسعار',
      description: 'تنبيهات تغير أسعار العملات',
      importance: Importance.high,
    );
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
    _ready = true;
  }

  Future<void> showPriceAlert({required String title, required String body}) async {
    await initialize();
    await _plugin.show(
      DateTime.now().microsecondsSinceEpoch.remainder(2147483647),
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'morre_price_alerts',
          'تنبيهات الأسعار',
          channelDescription: 'تنبيهات تغير أسعار العملات',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
    );
  }
}
