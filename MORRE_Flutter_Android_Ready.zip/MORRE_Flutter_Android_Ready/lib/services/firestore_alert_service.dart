import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/price_alert.dart';

class FirestoreAlertService {
  FirestoreAlertService(this.userId);
  final String userId;

  CollectionReference<Map<String, dynamic>> get _alerts =>
      FirebaseFirestore.instance.collection('users').doc(userId).collection('alerts');

  Stream<List<PriceAlert>> watch() => _alerts.snapshots().map((snap) {
        final items = snap.docs.map((d) => PriceAlert.fromMap(d.id, d.data())).toList();
        items.sort((a, b) => b.createdAt.compareTo(a.createdAt));
        return items;
      });

  Future<void> add(PriceAlert alert) => _alerts.doc(alert.id).set({
        ...alert.toMap(),
        'createdAt': FieldValue.serverTimestamp(),
        'createdAtClient': alert.createdAt.toIso8601String(),
      });

  Future<void> toggle(String id, bool enabled) =>
      _alerts.doc(id).update({'enabled': enabled, 'updatedAt': FieldValue.serverTimestamp()});

  Future<void> remove(String id) => _alerts.doc(id).delete();
}
