import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService {
  AuthService._();
  static final instance = AuthService._();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final GoogleSignIn _google = GoogleSignIn.instance;
  bool _googleInitialized = false;

  Stream<User?> get authStateChanges => _auth.authStateChanges();
  User? get currentUser => _auth.currentUser;

  Future<void> initializeGoogle() async {
    if (_googleInitialized) return;
    await _google.initialize();
    _googleInitialized = true;
  }

  Future<User> ensureAnonymousUser() async {
    final existing = _auth.currentUser;
    if (existing != null) return existing;
    final result = await _auth.signInAnonymously();
    final user = result.user!;
    await createUserProfile(user);
    return user;
  }

  Future<void> createUserProfile(User user) async {
    await _db.collection('users').doc(user.uid).set({
      'uid': user.uid,
      'email': user.email,
      'displayName': user.displayName,
      'isAnonymous': user.isAnonymous,
      'updatedAt': FieldValue.serverTimestamp(),
      'createdAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<UserCredential> register({
    required String email,
    required String password,
  }) async {
    final current = _auth.currentUser;
    final credential = EmailAuthProvider.credential(
      email: email.trim(),
      password: password,
    );

    late final UserCredential result;
    if (current != null && current.isAnonymous) {
      result = await current.linkWithCredential(credential);
    } else {
      result = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
    }
    await createUserProfile(result.user!);
    return result;
  }

  Future<UserCredential> login({required String email, required String password}) async {
    final result = await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    await createUserProfile(result.user!);
    return result;
  }

  Future<void> resetPassword(String email) {
    return _auth.sendPasswordResetEmail(email: email.trim());
  }

  Future<UserCredential> signInWithGoogle() async {
    await initializeGoogle();
    if (!_google.supportsAuthenticate()) {
      throw StateError('Google Sign-In غير مدعوم على هذه المنصة بهذه الطريقة.');
    }

    final googleUser = await _google.authenticate();
    final auth = await googleUser.authentication;
    final idToken = auth.idToken;
    if (idToken == null || idToken.isEmpty) {
      throw StateError('لم يتم الحصول على Google ID token.');
    }

    final credential = GoogleAuthProvider.credential(idToken: idToken);
    final current = _auth.currentUser;

    final result = current != null && current.isAnonymous
        ? await current.linkWithCredential(credential)
        : await _auth.signInWithCredential(credential);

    await createUserProfile(result.user!);
    return result;
  }

  Future<UserCredential> linkGoogleAccount() async {
    final current = _auth.currentUser;
    if (current == null) throw StateError('لا يوجد مستخدم حالي.');
    if (!current.isAnonymous) {
      throw StateError('الحساب بالفعل حساب دائم.');
    }
    await initializeGoogle();
    if (!_google.supportsAuthenticate()) {
      throw StateError('Google Sign-In غير مدعوم على هذه المنصة بهذه الطريقة.');
    }
    final googleUser = await _google.authenticate();
    final auth = await googleUser.authentication;
    final idToken = auth.idToken;
    if (idToken == null || idToken.isEmpty) {
      throw StateError('لم يتم الحصول على Google ID token.');
    }
    final result = await current.linkWithCredential(
      GoogleAuthProvider.credential(idToken: idToken),
    );
    await createUserProfile(result.user!);
    return result;
  }

  Future<void> updateProfile({String? displayName}) async {
    if (displayName != null) {
      await updateDisplayName(displayName);
    }
  }

  Future<void> updateDisplayName(String name) async {
    final user = _auth.currentUser;
    if (user == null) return;
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    await user.updateDisplayName(trimmed);
    await createUserProfile(user);
  }

  Future<void> signOut() => _auth.signOut();
}
