import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/price_history_point.dart';

enum ChartRange { h1, d1, w1, m1, m3, y1, all }

extension ChartRangeExtension on ChartRange {
  String get label => switch (this) {
        ChartRange.h1 => '1H',
        ChartRange.d1 => '1D',
        ChartRange.w1 => '1W',
        ChartRange.m1 => '1M',
        ChartRange.m3 => '3M',
        ChartRange.y1 => '1Y',
        ChartRange.all => 'ALL',
      };

  Duration? get duration => switch (this) {
        ChartRange.h1 => const Duration(hours: 1),
        ChartRange.d1 => const Duration(days: 1),
        ChartRange.w1 => const Duration(days: 7),
        ChartRange.m1 => const Duration(days: 30),
        ChartRange.m3 => const Duration(days: 90),
        ChartRange.y1 => const Duration(days: 365),
        ChartRange.all => null,
      };
}

class PriceHistoryService {
  PriceHistoryService._();
  static final instance = PriceHistoryService._();

  Stream<List<PriceHistoryPoint>> watch(String code, ChartRange range) {
    var query = FirebaseFirestore.instance
        .collection('currencies')
        .doc(code)
        .collection('history')
        .orderBy('timestamp', descending: false);
    final duration = range.duration;
    if (duration != null) {
      query = query.where(
        'timestamp',
        isGreaterThanOrEqualTo: Timestamp.fromDate(DateTime.now().subtract(duration)),
      );
    }
    return query.snapshots().map(
          (snapshot) => snapshot.docs.map(PriceHistoryPoint.fromFirestore).toList(),
        );
  }
}
