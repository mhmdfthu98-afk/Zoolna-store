import 'package:cloud_firestore/cloud_firestore.dart';

/// الخدمة المركزية لتحديث السعر من لوحة التحكم.
/// تحفظ السعر الحالي + نسخة تاريخية في عملية Batch واحدة.
class AdminPriceUpdateService {
  AdminPriceUpdateService._();
  static final instance = AdminPriceUpdateService._();

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> updateCurrencyPrice({
    required String code,
    required double buy,
    required double sell,
    Map<String, dynamic> extraData = const {},
  }) async {
    final currencyRef = _db.collection('currencies').doc(code);
    final historyRef = currencyRef.collection('history').doc();

    final batch = _db.batch();

    // السعر الحالي الذي يقرأه التطبيق مباشرة.
    batch.set(
      currencyRef,
      {
        'parallelBuy': buy,
        'parallelSell': sell,
        'updatedAt': FieldValue.serverTimestamp(),
        ...extraData,
      },
      SetOptions(merge: true),
    );

    // Snapshot تاريخي للرسم البياني.
    batch.set(historyRef, {
      'price': sell,
      'buy': buy,
      'sell': sell,
      'timestamp': FieldValue.serverTimestamp(),
      'source': 'admin_dashboard',
    });

    await batch.commit();
  }
}