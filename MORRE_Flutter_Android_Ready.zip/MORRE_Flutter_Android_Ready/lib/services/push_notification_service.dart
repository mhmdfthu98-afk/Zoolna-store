import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class PushNotificationService {
  PushNotificationService._();
  static final instance = PushNotificationService._();

  final _messaging = FirebaseMessaging.instance;
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;
  final _local = FlutterLocalNotificationsPlugin();
  StreamSubscription<String>? _tokenSub;
  StreamSubscription<RemoteMessage>? _foregroundSub;
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;

    await _messaging.requestPermission(alert: true, badge: true, sound: true);

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _local.initialize(const InitializationSettings(android: android));
    const channel = AndroidNotificationChannel(
      'morre_push_alerts',
      'تنبيهات MORRE',
      description: 'تنبيهات أسعار العملات ورسائل MORRE',
      importance: Importance.high,
    );
    await _local
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    await _saveToken();
    _tokenSub = _messaging.onTokenRefresh.listen((_) => _saveToken());
    _foregroundSub = FirebaseMessaging.onMessage.listen(_showForegroundNotification);
  }

  Future<void> _saveToken() async {
    final user = _auth.currentUser;
    if (user == null) return;
    final token = await _messaging.getToken();
    if (token == null || token.isEmpty) return;
    await _db.collection('users').doc(user.uid).collection('devices').doc(token).set({
      'fcmToken': token,
      'platform': 'android',
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> _showForegroundNotification(RemoteMessage message) async {
    final notification = message.notification;
    if (notification == null) return;
    await _local.show(
      DateTime.now().microsecondsSinceEpoch.remainder(2147483647),
      notification.title,
      notification.body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'morre_push_alerts',
          'تنبيهات MORRE',
          channelDescription: 'تنبيهات أسعار العملات ورسائل MORRE',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
    );
  }

  Future<void> dispose() async {
    await _tokenSub?.cancel();
    await _foregroundSub?.cancel();
  }
}
