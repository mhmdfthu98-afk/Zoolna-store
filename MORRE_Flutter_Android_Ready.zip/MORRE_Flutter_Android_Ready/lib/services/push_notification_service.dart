import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class PushNotificationService {
  PushNotificationService._();

  static final PushNotificationService instance =
      PushNotificationService._();

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  final FlutterLocalNotificationsPlugin _local =
      FlutterLocalNotificationsPlugin();

  StreamSubscription<String>? _tokenSub;
  StreamSubscription<RemoteMessage>? _foregroundSub;

  bool _initialized = false;

  static const String channelId = 'morre_push_alerts';
  static const String channelName = 'تنبيهات MORRE';

  Future<void> initialize() async {
    if (_initialized) return;

    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const initializationSettings = InitializationSettings(
      android: androidSettings,
    );

    await _local.initialize(
      initializationSettings,
    );

    const channel = AndroidNotificationChannel(
      channelId,
      channelName,
      description: 'تنبيهات أسعار العملات ورسائل MORRE',
      importance: Importance.high,
    );

    final androidPlugin = _local
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    await androidPlugin?.createNotificationChannel(channel);

    await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    await _saveToken();

    _tokenSub = _messaging.onTokenRefresh.listen(
      (_) async {
        await _saveToken();
      },
    );

    _foregroundSub = FirebaseMessaging.onMessage.listen(
      _showForegroundNotification,
    );

    _initialized = true;
  }

  Future<void> _saveToken() async {
    final user = _auth.currentUser;

    if (user == null) return;

    try {
      final token = await _messaging.getToken();

      if (token == null || token.isEmpty) return;

      await _db
          .collection('users')
          .doc(user.uid)
          .collection('devices')
          .doc(token)
          .set(
        {
          'fcmToken': token,
          'platform': 'android',
          'updatedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
    } catch (_) {
      // لا نوقف التطبيق إذا فشل حفظ التوكن.
    }
  }

  Future<void> _showForegroundNotification(
    RemoteMessage message,
  ) async {
    final notification = message.notification;

    if (notification == null) return;

    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        channelId,
        channelName,
        channelDescription: 'تنبيهات أسعار العملات ورسائل MORRE',
        importance: Importance.high,
        priority: Priority.high,
      ),
    );

    await _local.show(
      DateTime.now().microsecondsSinceEpoch.remainder(2147483647),
      notification.title ?? 'MORRE',
      notification.body ?? '',
      details,
    );
  }

  Future<void> dispose() async {
    await _tokenSub?.cancel();
    await _foregroundSub?.cancel();

    _tokenSub = null;
    _foregroundSub = null;
  }
}