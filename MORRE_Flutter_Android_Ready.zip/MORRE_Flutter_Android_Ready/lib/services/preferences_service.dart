import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PreferencesService {
  PreferencesService._();

  static final PreferencesService instance = PreferencesService._();

  FirebaseFirestore get _db => FirebaseFirestore.instance;

  String get uid {
    final value = FirebaseAuth.instance.currentUser?.uid;

    if (value == null) {
      throw StateError('المستخدم غير مسجل.');
    }

    return value;
  }

  DocumentReference<Map<String, dynamic>> get prefsRef =>
      _db.collection('users').doc(uid).collection('settings').doc('preferences');

  CollectionReference<Map<String, dynamic>> get favoritesRef =>
      _db.collection('users').doc(uid).collection('favorites');

  Stream<Map<String, dynamic>> preferencesStream() {
    return prefsRef.snapshots().map(
          (doc) => doc.data() ?? <String, dynamic>{},
        );
  }

  Stream<List<QueryDocumentSnapshot<Map<String, dynamic>>>> favoritesStream() {
    return favoritesRef
        .orderBy('order')
        .snapshots()
        .map((snap) => snap.docs);
  }

  Future<void> initialize() async {
    await prefsRef.set(
      {
        'themeMode': 'system',
        'language': 'ar',
        'hiddenCurrencies': <String>[],
        'notifications': {
          'priceAlerts': true,
          'marketUpdates': true,
          'generalNotifications': true,
          'sound': true,
          'vibration': true,
        },
        'updatedAt': FieldValue.serverTimestamp(),
      },
      SetOptions(merge: true),
    );
  }

  Future<void> updateAppSettings({
    String? themeMode,
    String? language,
  }) async {
    final data = <String, dynamic>{
      'updatedAt': FieldValue.serverTimestamp(),
    };

    if (themeMode != null) {
      data['themeMode'] = themeMode;
    }

    if (language != null) {
      data['language'] = language;
    }

    await prefsRef.set(
      data,
      SetOptions(merge: true),
    );
  }

  Future<void> updateNotificationSettings(
    Map<String, bool> values,
  ) async {
    await prefsRef.set(
      {
        'notifications': values,
        'updatedAt': FieldValue.serverTimestamp(),
      },
      SetOptions(merge: true),
    );
  }

  Future<void> setHiddenCurrencies(
    List<String> codes,
  ) async {
    await prefsRef.set(
      {
        'hiddenCurrencies': codes.toSet().toList(),
        'updatedAt': FieldValue.serverTimestamp(),
      },
      SetOptions(merge: true),
    );
  }

  Future<void> toggleFavorite(String code) async {
    final ref = favoritesRef.doc(code);

    final existing = await ref.get();

    if (existing.exists) {
      await ref.delete();
      return;
    }

    final existingDocs = await favoritesRef.get();

    final maxOrder = existingDocs.docs.fold<int>(
      -1,
      (max, doc) {
        final order =
            (doc.data()['order'] as num?)?.toInt() ?? 0;

        return order > max ? order : max;
      },
    );

    await ref.set({
      'code': code,
      'order': maxOrder + 1,
      'pinned': false,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> togglePinned(
    String code,
    bool pinned,
  ) async {
    await favoritesRef.doc(code).set(
      {
        'code': code,
        'pinned': pinned,
        'updatedAt': FieldValue.serverTimestamp(),
      },
      SetOptions(merge: true),
    );
  }

  Future<bool> isFavorite(String code) async {
    final snapshot = await favoritesRef.doc(code).get();

    return snapshot.exists;
  }

  Future<void> reorderFavorites(
    List<String> codes,
  ) async {
    final batch = _db.batch();

    for (var i = 0; i < codes.length; i++) {
      batch.set(
        favoritesRef.doc(codes[i]),
        {
          'code': codes[i],
          'order': i,
          'updatedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
    }

    await batch.commit();
  }

  // إعادة جميع إعدادات المستخدم للوضع الافتراضي.
  Future<void> resetPreferences() async {
    await prefsRef.set(
      {
        'themeMode': 'system',
        'language': 'ar',
        'hiddenCurrencies': <String>[],
        'notifications': {
          'priceAlerts': true,
          'marketUpdates': true,
          'generalNotifications': true,
          'sound': true,
          'vibration': true,
        },
        'updatedAt': FieldValue.serverTimestamp(),
      },
      SetOptions(merge: true),
    );
  }
}