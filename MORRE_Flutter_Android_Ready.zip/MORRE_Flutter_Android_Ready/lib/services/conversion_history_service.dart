import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class ConversionHistoryItem {
  final double amount;
  final String fromCode;
  final String toCode;
  final double result;
  final bool parallel;
  final bool sellRate;
  final DateTime createdAt;

  ConversionHistoryItem({
    required this.amount,
    required this.fromCode,
    required this.toCode,
    required this.result,
    required this.parallel,
    required this.sellRate,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
    'amount': amount,
    'fromCode': fromCode,
    'toCode': toCode,
    'result': result,
    'parallel': parallel,
    'sellRate': sellRate,
    'createdAt': createdAt.toIso8601String(),
  };

  factory ConversionHistoryItem.fromJson(Map<String, dynamic> json) {
    return ConversionHistoryItem(
      amount: (json['amount'] as num).toDouble(),
      fromCode: json['fromCode'].toString(),
      toCode: json['toCode'].toString(),
      result: (json['result'] as num).toDouble(),
      parallel: json['parallel'] == true,
      sellRate: json['sellRate'] == true,
      createdAt: DateTime.parse(json['createdAt'].toString()),
    );
  }
}

class ConversionHistoryService {
  static const _key = 'conversion_history';

  Future<List<ConversionHistoryItem>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];

    final items = raw
        .map((item) => ConversionHistoryItem.fromJson(
              Map<String, dynamic>.from(jsonDecode(item)),
            ))
        .toList();

    items.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return items;
  }

  Future<void> add(ConversionHistoryItem item) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await load();

    current.insert(0, item);
    final limited = current.take(30).toList();

    await prefs.setStringList(
      _key,
      limited.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}