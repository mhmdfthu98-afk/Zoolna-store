import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/currency.dart';
class CurrencyService {
 final _db=FirebaseFirestore.instance;
 Stream<List<Currency>> watchCurrencies()=>_db.collection('currencies').snapshots().map((s)=>s.docs.map((d)=>Currency.fromMap(d.id,d.data())).toList());
}
