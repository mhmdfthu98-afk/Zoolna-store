import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/preferences_service.dart';

class CustomizeHomeScreen extends StatefulWidget {
  const CustomizeHomeScreen({super.key});

  @override
  State<CustomizeHomeScreen> createState() => _CustomizeHomeScreenState();
}

class _CustomizeHomeScreenState extends State<CustomizeHomeScreen> {
  Set<String> hidden = {};
  bool _initializedFromPreferences = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تخصيص الصفحة الرئيسية'),
      ),
      body: StreamBuilder<Map<String, dynamic>>(
        stream: PreferencesService.instance.preferencesStream(),
        builder: (context, prefSnapshot) {
          final pref = prefSnapshot.data ?? {};

          if (!_initializedFromPreferences && prefSnapshot.hasData) {
            final savedHidden = pref['hiddenCurrencies'];

            hidden = savedHidden is List
                ? Set<String>.from(
                    savedHidden.map((item) => item.toString()),
                  )
                : {};

            _initializedFromPreferences = true;
          }

          return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance
                .collection('currencies')
                .orderBy('code')
                .snapshots(),
            builder: (context, currencySnapshot) {
              if (currencySnapshot.hasError) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      'حدث خطأ أثناء تحميل العملات:\n${currencySnapshot.error}',
                      textAlign: TextAlign.center,
                    ),
                  ),
                );
              }

              if (currencySnapshot.connectionState ==
                      ConnectionState.waiting &&
                  !currencySnapshot.hasData) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }

              final currencies = currencySnapshot.data?.docs ?? [];

              if (currencies.isEmpty) {
                return const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'لا توجد عملات متاحة حاليًا.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                );
              }

              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Text(
                    'تخصيص الصفحة الرئيسية',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  const SizedBox(height: 8),

                  Text(
                    'اختر العملات التي تريد إظهارها في الصفحة الرئيسية.',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),

                  const SizedBox(height: 8),

                  Text(
                    'إخفاء العملة لا يحذفها من قاعدة البيانات، ويمكنك إظهارها مرة أخرى في أي وقت.',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),

                  const SizedBox(height: 20),

                  ...currencies.map((doc) {
                    final data = doc.data();

                    final code = doc.id;
                    final name = data['name']?.toString() ?? code;

                    final isVisible = !hidden.contains(code);

                    return Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: SwitchListTile(
                        secondary: CircleAvatar(
                          child: Text(
                            code.length > 3
                                ? code.substring(0, 3)
                                : code,
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        title: Text(
                          name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: Text(code),
                        value: isVisible,
                        onChanged: (visible) async {
                          setState(() {
                            if (visible) {
                              hidden.remove(code);
                            } else {
                              hidden.add(code);
                            }
                          });

                          try {
                            await PreferencesService.instance
                                .setHiddenCurrencies(
                              hidden.toList(),
                            );
                          } catch (e) {
                            if (!mounted) return;

                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  'تعذر حفظ الإعدادات: $e',
                                ),
                              ),
                            );
                          }
                        },
                      ),
                    );
                  }),

                  const SizedBox(height: 12),

                  OutlinedButton.icon(
                    onPressed: () async {
                      try {
                        await PreferencesService.instance
                            .resetPreferences();

                        if (!mounted) return;

                        setState(() {
                          hidden = {};
                          _initializedFromPreferences = true;
                        });

                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                              'تمت إعادة الإعدادات الافتراضية',
                            ),
                          ),
                        );
                      } catch (e) {
                        if (!mounted) return;

                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'تعذر إعادة الإعدادات: $e',
                            ),
                          ),
                        );
                      }
                    },
                    icon: const Icon(Icons.restart_alt),
                    label: const Text(
                      'إعادة الإعدادات الافتراضية',
                    ),
                  ),

                  const SizedBox(height: 16),
                ],
              );
            },
          );
        },
      ),
    );
  }
}