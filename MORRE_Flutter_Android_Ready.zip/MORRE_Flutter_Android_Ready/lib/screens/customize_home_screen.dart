import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/preferences_service.dart';

class CustomizeHomeScreen extends StatefulWidget {
  const CustomizeHomeScreen({super.key});

  @override
  State<CustomizeHomeScreen> createState() => _CustomizeHomeScreenState();
}

class _CustomizeHomeScreenState extends State<CustomizeHomeScreen> {
  Set<String> hidden = {};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تخصيص الصفحة الرئيسية')),
      body: StreamBuilder<Map<String, dynamic>>(
        stream: PreferencesService.instance.preferencesStream(),
        builder: (context, prefSnapshot) {
          final pref = prefSnapshot.data ?? {};
          if (prefSnapshot.hasData && hidden.isEmpty) {
            hidden = Set<String>.from(pref['hiddenCurrencies'] ?? []);
          }

          return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance.collection('currencies').orderBy('code').snapshots(),
            builder: (context, currencySnapshot) {
              final currencies = currencySnapshot.data?.docs ?? [];

              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Text(
                    'اختر العملات التي تريد إظهارها في الصفحة الرئيسية',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  const Text('إخفاء العملة لا يحذفها، ويمكنك إظهارها لاحقًا.'),
                  const SizedBox(height: 16),

                  ...currencies.map((doc) {
                    final data = doc.data();
                    final isVisible = !hidden.contains(doc.id);
                    return Card(
                      child: SwitchListTile(
                        secondary: CircleAvatar(child: Text(doc.id)),
                        title: Text(data['name']?.toString() ?? doc.id),
                        subtitle: Text(doc.id),
                        value: isVisible,
                        onChanged: (visible) async {
                          setState(() {
                            if (visible) {
                              hidden.remove(doc.id);
                            } else {
                              hidden.add(doc.id);
                            }
                          });
                          await PreferencesService.instance
                              .setHiddenCurrencies(hidden.toList());
                        },
                      ),
                    );
                  }),

                  const SizedBox(height: 16),
                  OutlinedButton.icon(
                    onPressed: () async {
                      await PreferencesService.instance.resetPreferences();
                      if (mounted) {
                        setState(() => hidden = {});
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('تمت إعادة الإعدادات الافتراضية')),
                        );
                      }
                    },
                    icon: const Icon(Icons.restart_alt),
                    label: const Text('إعادة الإعدادات الافتراضية'),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}