import 'package:flutter/material.dart';
import '../services/conversion_history_service.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final _service = ConversionHistoryService();
  List<ConversionHistoryItem> items = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result = await _service.load();
    if (mounted) {
      setState(() {
        items = result;
        loading = false;
      });
    }
  }

  Future<void> _clear() async {
    await _service.clear();
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('سجل التحويلات'),
        actions: [
          if (items.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: _clear,
            ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : items.isEmpty
              ? const Center(child: Text('لا يوجد سجل تحويلات بعد'))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      final item = items[index];
                      return Card(
                        child: ListTile(
                          leading: const Icon(Icons.currency_exchange),
                          title: Text(
                            '${item.amount.toStringAsFixed(2)} ${item.fromCode} → ${item.result.toStringAsFixed(2)} ${item.toCode}',
                          ),
                          subtitle: Text(
                            '${item.parallel ? 'الموازي' : 'الرسمي'} • ${item.sellRate ? 'بيع' : 'شراء'}',
                          ),
                          trailing: Text(
                            '${item.createdAt.hour.toString().padLeft(2, '0')}:${item.createdAt.minute.toString().padLeft(2, '0')}',
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}