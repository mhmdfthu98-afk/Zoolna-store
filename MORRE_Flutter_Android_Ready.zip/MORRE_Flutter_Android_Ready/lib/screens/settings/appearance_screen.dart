import 'package:flutter/material.dart';
import '../../services/preferences_service.dart';

class AppearanceScreen extends StatelessWidget {
  final ThemeMode value;
  final ValueChanged<ThemeMode> onChanged;
  const AppearanceScreen({super.key, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('المظهر')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _option(context, ThemeMode.light, 'الوضع الفاتح', Icons.light_mode),
            _option(context, ThemeMode.dark, 'الوضع الداكن', Icons.dark_mode),
            _option(context, ThemeMode.system, 'حسب الجهاز', Icons.phone_android),
          ],
        ),
      );

  Widget _option(BuildContext context, ThemeMode mode, String title, IconData icon) =>
      Card(child: RadioListTile<ThemeMode>(
        value: mode,
        groupValue: value,
        secondary: Icon(icon),
        title: Text(title),
        onChanged: (v) async {
          if (v == null) return;
          onChanged(v);
          await PreferencesService.instance.updateAppSettings(
            themeMode: switch (v) {
              ThemeMode.light => 'light',
              ThemeMode.dark => 'dark',
              _ => 'system',
            },
          );
        },
      ));
}
