import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../services/auth_service.dart';
import '../../services/preferences_service.dart';
import '../login_screen.dart';
import 'appearance_screen.dart';
import 'language_screen.dart';
import 'notifications_settings_screen.dart';
import 'about_screen.dart';

class SettingsScreen extends StatelessWidget {
  final ThemeMode themeMode;
  final Locale locale;
  final ValueChanged<ThemeMode> onThemeChanged;
  final ValueChanged<Locale> onLocaleChanged;

  const SettingsScreen({
    super.key,
    required this.themeMode,
    required this.locale,
    required this.onThemeChanged,
    required this.onLocaleChanged,
  });

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.person)),
              title: Text(user?.isAnonymous == true ? 'مستخدم ضيف' : (user?.email ?? 'حساب MORRE')),
              subtitle: Text(user?.isAnonymous == true ? 'اربط حسابك لحفظ بياناتك على أجهزة أخرى' : 'الحساب مرتبط'),
            ),
          ),
          const SizedBox(height: 16),
          ListTile(
            leading: const Icon(Icons.palette_outlined),
            title: const Text('المظهر'),
            subtitle: Text(themeMode == ThemeMode.dark ? 'داكن' : themeMode == ThemeMode.light ? 'فاتح' : 'حسب الجهاز'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AppearanceScreen(value: themeMode, onChanged: onThemeChanged))),
          ),
          ListTile(
            leading: const Icon(Icons.language),
            title: const Text('اللغة'),
            subtitle: Text(locale.languageCode == 'en' ? 'English' : 'العربية'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LanguageScreen(value: locale, onChanged: onLocaleChanged))),
          ),
          ListTile(
            leading: const Icon(Icons.notifications_outlined),
            title: const Text('الإشعارات'),
            subtitle: const Text('تنبيهات الأسعار ورسائل MORRE'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsSettingsScreen())),
          ),
          const Divider(height: 30),
          ListTile(
            leading: const Icon(Icons.person_outline),
            title: const Text('الحساب'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountSettingsScreen()));
            },
          ),
          ListTile(
            leading: const Icon(Icons.tune),
            title: const Text('إعدادات الصفحة الرئيسية'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('حول MORRE'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutScreen())),
          ),
          const SizedBox(height: 20),
          const Text('تُحفظ تفضيلاتك في Firebase لحسابك الحالي.'),
        ],
      ),
    );
  }
}

class AccountSettingsScreen extends StatelessWidget {
  const AccountSettingsScreen({super.key});

  Future<void> _login(BuildContext context, {bool register = false}) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => LoginScreen(showRegister: register)));
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: AuthService.instance.authStateChanges,
      builder: (context, snapshot) {
        final user = snapshot.data ?? AuthService.instance.currentUser;
        final anonymous = user?.isAnonymous ?? true;
        return Scaffold(
          appBar: AppBar(title: const Text('الحساب')),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(child: ListTile(
                leading: const Icon(Icons.email_outlined),
                title: Text(anonymous ? 'مستخدم ضيف' : (user?.email ?? 'حساب MORRE')),
                subtitle: Text(user?.uid ?? ''),
              )),
              if (anonymous) ...[
                const SizedBox(height: 12),
                FilledButton.icon(onPressed: () => _login(context, register: true), icon: const Icon(Icons.person_add_alt_1), label: const Text('إنشاء حساب دائم')),
                const SizedBox(height: 8),
                OutlinedButton.icon(onPressed: () => _login(context), icon: const Icon(Icons.login), label: const Text('تسجيل الدخول')),
              ] else ...[
                const SizedBox(height: 12),
                ListTile(
                  leading: const Icon(Icons.lock_reset),
                  title: const Text('استعادة كلمة المرور'),
                  onTap: () async {
                    final email = user?.email;
                    if (email == null) return;
                    await AuthService.instance.resetPassword(email);
                    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إرسال رابط الاستعادة.')));
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.logout),
                  title: const Text('تسجيل الخروج'),
                  onTap: () async {
                    await AuthService.instance.signOut();
                    await AuthService.instance.ensureAnonymousUser();
                    if (context.mounted) Navigator.pop(context);
                  },
                ),
              ],
              const SizedBox(height: 12),
              const Text('ملاحظة: ربط الحساب بالحساب الحالي يحافظ على تنبيهاتك وإعداداتك.'),
            ],
          ),
        );
      },
    );
  }
}
