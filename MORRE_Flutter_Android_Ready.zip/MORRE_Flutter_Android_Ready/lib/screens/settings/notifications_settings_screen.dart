import 'package:flutter/material.dart';
import '../../services/preferences_service.dart';

class NotificationsSettingsScreen extends StatelessWidget {
  const NotificationsSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) => StreamBuilder<Map<String, dynamic>>(
        stream: PreferencesService.instance.preferencesStream(),
        builder: (context, snapshot) {
          final raw = Map<String, dynamic>.from(snapshot.data?['notifications'] ?? {});
          bool value(String key, [bool fallback = true]) => raw[key] is bool ? raw[key] as bool : fallback;
          return Scaffold(
            appBar: AppBar(title: const Text('إعدادات الإشعارات')),
            body: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _switch(context, 'تنبيهات الأسعار', 'priceAlerts', value('priceAlerts')),
                _switch(context, 'تحديثات السوق', 'marketUpdates', value('marketUpdates')),
                _switch(context, 'الإشعارات العامة', 'generalNotifications', value('generalNotifications')),
                const Divider(height: 30),
                _switch(context, 'صوت الإشعار', 'sound', value('sound')),
                _switch(context, 'الاهتزاز', 'vibration', value('vibration')),
              ],
            ),
          );
        },
      );

  Widget _switch(BuildContext context, String title, String keyName, bool current) =>
      Card(child: SwitchListTile(
        title: Text(title),
        value: current,
        onChanged: (v) async {
          await PreferencesService.instance.updateNotificationSettings({keyName: v});
        },
      ));
}
