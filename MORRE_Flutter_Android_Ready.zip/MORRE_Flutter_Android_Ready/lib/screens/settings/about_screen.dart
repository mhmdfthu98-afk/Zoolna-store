import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('حول MORRE')),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              CircleAvatar(radius: 38, child: Icon(Icons.currency_exchange, size: 42)),
              SizedBox(height: 16),
              Text('MORRE', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('أسعار العملات • تنبيهات • رسوم بيانية', textAlign: TextAlign.center),
              SizedBox(height: 16),
              Text('الإصدار 1.0.0'),
            ]),
          ),
        ),
      );
}
