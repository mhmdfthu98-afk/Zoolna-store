import 'package:flutter/material.dart';
import '../../services/preferences_service.dart';

class LanguageScreen extends StatelessWidget {
  final Locale value;
  final ValueChanged<Locale> onChanged;
  const LanguageScreen({super.key, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('اللغة')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _option(context, const Locale('ar'), '🇸🇩 العربية'),
            _option(context, const Locale('en'), '🇬🇧 English'),
          ],
        ),
      );

  Widget _option(BuildContext context, Locale locale, String title) =>
      Card(child: RadioListTile<Locale>(
        value: locale,
        groupValue: value,
        title: Text(title),
        onChanged: (v) async {
          if (v == null) return;
          onChanged(v);
          await PreferencesService.instance.updateAppSettings(language: v.languageCode);
        },
      ));
}
