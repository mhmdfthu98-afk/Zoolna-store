import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/preferences_service.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: PreferencesService.instance.favoritesStream(),
      builder: (context, snapshot) {
        final docs = snapshot.data?.docs ?? [];

        if (docs.isEmpty) {
          return const Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.star_border, size: 70),
                SizedBox(height: 16),
                Text('لا توجد عملات مفضلة'),
                SizedBox(height: 8),
                Text('أضف العملات المهمة بالنسبة لك من الصفحة الرئيسية'),
              ],
            ),
          );
        }

        return ReorderableListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: docs.length,
          onReorder: (oldIndex, newIndex) async {
            if (newIndex > oldIndex) newIndex--;
            final items = [...docs];
            final item = items.removeAt(oldIndex);
            items.insert(newIndex, item);
            await PreferencesService.instance.reorderFavorites(
              items.map((e) => e.id).toList(),
            );
          },
          itemBuilder: (context, index) {
            final doc = docs[index];
            final data = doc.data();
            final pinned = data['pinned'] == true;

            return Card(
              key: ValueKey(doc.id),
              child: ListTile(
                leading: Icon(
                  pinned ? Icons.push_pin : Icons.star,
                  color: pinned ? Colors.orange : null,
                ),
                title: Text(doc.id),
                subtitle: Text(pinned ? 'مثبت في أعلى الصفحة الرئيسية' : 'عملة مفضلة'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      tooltip: pinned ? 'إلغاء التثبيت' : 'تثبيت',
                      icon: Icon(pinned ? Icons.push_pin : Icons.push_pin_outlined),
                      onPressed: () => PreferencesService.instance.togglePinned(
                        doc.id,
                        pinned: !pinned,
                      ),
                    ),
                    const Icon(Icons.drag_handle),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}