import 'package:flutter/material.dart';
import '../models/currency.dart';
import '../models/price_alert.dart';
import '../services/auth_service.dart';
import '../services/currency_service.dart';
import '../services/firestore_alert_service.dart';

class AlertsScreen extends StatefulWidget {
  const AlertsScreen({super.key});

  @override
  State<AlertsScreen> createState() => _AlertsScreenState();
}

class _AlertsScreenState extends State<AlertsScreen> {
  FirestoreAlertService? _service;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    final user = await AuthService.instance.ensureAnonymousUser();
    await AuthService.instance.createUserProfile(user);
    if (!mounted) return;
    setState(() => _service = FirestoreAlertService(user.uid));
  }

  Future<void> _addDialog(List<Currency> currencies) async {
    if (_service == null || currencies.isEmpty) return;
    String code = currencies.first.code;
    String market = 'parallel';
    String type = 'above';
    final controller = TextEditingController();

    await showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('إضافة تنبيه سعري'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButtonFormField<String>(
                value: code,
                decoration: const InputDecoration(labelText: 'العملة'),
                items: currencies.map((c) => DropdownMenuItem(
                  value: c.code,
                  child: Text('${c.flag} ${c.name} (${c.code})'),
                )).toList(),
                onChanged: (v) { if (v != null) setDialogState(() => code = v); },
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: market,
                decoration: const InputDecoration(labelText: 'السوق'),
                items: const [
                  DropdownMenuItem(value: 'official', child: Text('السوق الرسمي')),
                  DropdownMenuItem(value: 'parallel', child: Text('السوق الموازي')),
                ],
                onChanged: (v) { if (v != null) setDialogState(() => market = v); },
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: type,
                decoration: const InputDecoration(labelText: 'شرط التنبيه'),
                items: const [
                  DropdownMenuItem(value: 'above', child: Text('عند الارتفاع إلى أو فوق السعر')),
                  DropdownMenuItem(value: 'below', child: Text('عند الانخفاض إلى أو تحت السعر')),
                ],
                onChanged: (v) { if (v != null) setDialogState(() => type = v); },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: controller,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'السعر المستهدف'),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () async {
                final target = double.tryParse(controller.text.trim());
                if (target == null || target <= 0) return;
                await _service!.add(PriceAlert(
                  id: DateTime.now().microsecondsSinceEpoch.toString(),
                  currencyCode: code,
                  targetPrice: target,
                  market: market,
                  type: type,
                  enabled: true,
                  createdAt: DateTime.now(),
                ));
                if (dialogContext.mounted) Navigator.pop(dialogContext);
              },
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Currency>>(
      stream: CurrencyService().watchCurrencies(),
      builder: (context, currencySnapshot) {
        final currencies = currencySnapshot.data ?? [];
        if (_service == null) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }

        return Scaffold(
          appBar: AppBar(title: const Text('تنبيهات الأسعار')),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _addDialog(currencies),
            icon: const Icon(Icons.add_alert),
            label: const Text('إضافة تنبيه'),
          ),
          body: StreamBuilder<List<PriceAlert>>(
            stream: _service!.watch(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Center(child: Text('خطأ: ${snapshot.error}'));
              }
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final alerts = snapshot.data!;
              if (alerts.isEmpty) {
                return const Center(child: Text('لا توجد تنبيهات سعرية'));
              }
              return ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                itemCount: alerts.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (_, index) {
                  final alert = alerts[index];
                  return Card(
                    child: ListTile(
                      leading: Icon(alert.type == 'above'
                          ? Icons.trending_up : Icons.trending_down),
                      title: Text('${alert.currencyCode} • ${alert.targetPrice.toStringAsFixed(2)}'),
                      subtitle: Text(
                        '${alert.market == 'official' ? 'السوق الرسمي' : 'السوق الموازي'} • '
                        '${alert.type == 'above' ? 'ارتفاع' : 'انخفاض'}',
                      ),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        Switch(
                          value: alert.enabled,
                          onChanged: (v) => _service!.toggle(alert.id, v),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => _service!.remove(alert.id),
                        ),
                      ]),
                    ),
                  );
                },
              );
            },
          ),
        );
      },
    );
  }
}