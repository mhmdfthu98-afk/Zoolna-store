import 'package:flutter/material.dart';
import '../models/currency.dart';
import '../services/currency_service.dart';
import '../services/conversion_history_service.dart';
import 'history_screen.dart';

class ConverterScreen extends StatefulWidget {
  const ConverterScreen({super.key});

  @override
  State<ConverterScreen> createState() => _ConverterScreenState();
}

class _ConverterScreenState extends State<ConverterScreen> {
  final _amountController = TextEditingController(text: '1');
  final _service = CurrencyService();
  final _historyService = ConversionHistoryService();

  String? fromCode;
  String? toCode;
  bool useParallel = true;
  bool useSellRate = false;

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  double _rate(Currency c) {
    if (useParallel) return useSellRate ? c.parallelSell : c.parallelBuy;
    return useSellRate ? c.officialSell : c.officialBuy;
  }

  double _convert(List<Currency> currencies) {
    if (fromCode == null || toCode == null) return 0;
    final amount = double.tryParse(_amountController.text) ?? 0;
    if (fromCode == toCode) return amount;

    final from = currencies.firstWhere((c) => c.code == fromCode);
    final to = currencies.firstWhere((c) => c.code == toCode);
    final fromRate = _rate(from);
    final toRate = _rate(to);

    if (fromRate == 0 || toRate == 0) return 0;
    return amount * fromRate / toRate;
  }

  Future<void> _saveHistory(double result) async {
    final amount = double.tryParse(_amountController.text) ?? 0;
    if (fromCode == null || toCode == null || amount <= 0) return;

    await _historyService.add(
      ConversionHistoryItem(
        amount: amount,
        fromCode: fromCode!,
        toCode: toCode!,
        result: result,
        parallel: useParallel,
        sellRate: useSellRate,
        createdAt: DateTime.now(),
      ),
    );

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حفظ العملية في سجل التحويلات')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Currency>>(
      stream: _service.watchCurrencies(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }

        final currencies = snapshot.data!;
        if (currencies.isEmpty) {
          return const Scaffold(body: Center(child: Text('لا توجد عملات للتحويل')));
        }

        fromCode ??= currencies.first.code;
        toCode ??= currencies.length > 1 ? currencies[1].code : currencies.first.code;
        final result = _convert(currencies);

        return Scaffold(
          appBar: AppBar(
            title: const Text('محول العملات'),
            centerTitle: true,
            actions: [
              IconButton(
                tooltip: 'سجل التحويلات',
                icon: const Icon(Icons.history),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const HistoryScreen()),
                  );
                },
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              TextField(
                controller: _amountController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  labelText: 'المبلغ',
                  prefixIcon: const Icon(Icons.numbers),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                ),
              ),
              const SizedBox(height: 16),
              _dropdown('من', fromCode, currencies, (v) => setState(() => fromCode = v)),
              Center(
                child: IconButton.filledTonal(
                  icon: const Icon(Icons.swap_vert),
                  onPressed: () => setState(() {
                    final old = fromCode;
                    fromCode = toCode;
                    toCode = old;
                  }),
                ),
              ),
              _dropdown('إلى', toCode, currencies, (v) => setState(() => toCode = v)),
              const SizedBox(height: 12),
              SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: false, label: Text('الرسمي')),
                  ButtonSegment(value: true, label: Text('الموازي')),
                ],
                selected: {useParallel},
                onSelectionChanged: (v) => setState(() => useParallel = v.first),
              ),
              const SizedBox(height: 12),
              SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: false, label: Text('شراء')),
                  ButtonSegment(value: true, label: Text('بيع')),
                ],
                selected: {useSellRate},
                onSelectionChanged: (v) => setState(() => useSellRate = v.first),
              ),
              const SizedBox(height: 24),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      const Text('النتيجة'),
                      const SizedBox(height: 10),
                      Text(
                        result.toStringAsFixed(2),
                        style: Theme.of(context).textTheme.displaySmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text('$fromCode → $toCode'),
                      const SizedBox(height: 16),
                      FilledButton.icon(
                        onPressed: () => _saveHistory(result),
                        icon: const Icon(Icons.save_outlined),
                        label: const Text('حفظ في السجل'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _dropdown(String label, String? value, List<Currency> currencies, ValueChanged<String?> onChanged) {
    return DropdownButtonFormField<String>(
      value: value,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
      ),
      items: currencies.map((c) => DropdownMenuItem(
        value: c.code,
        child: Text('${c.flag} ${c.name} (${c.code})'),
      )).toList(),
      onChanged: onChanged,
    );
  }
}