import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/currency.dart';
import '../services/preferences_service.dart';
import '../widgets/currency_card.dart';
import 'currency_detail_screen.dart';
import 'customize_home_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String query = '';

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Map<String, dynamic>>(
      stream: PreferencesService.instance.preferencesStream(),
      builder: (context, prefSnapshot) {
        final hidden = Set<String>.from(
          prefSnapshot.data?['hiddenCurrencies'] ?? const [],
        );

        return Scaffold(
          body: SafeArea(
            child: RefreshIndicator(
              onRefresh: () async => setState(() {}),
              child: CustomScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                slivers: [
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
                    sliver: SliverToBoxAdapter(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const CircleAvatar(
                                radius: 24,
                                child: Icon(Icons.currency_exchange),
                              ),
                              const SizedBox(width: 12),
                              const Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'MORRE',
                                      style: TextStyle(
                                        fontSize: 24,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                    Text('أسعار العملات • تحديث مباشر'),
                                  ],
                                ),
                              ),
                              IconButton(
                                tooltip: 'تخصيص الصفحة',
                                icon: const Icon(Icons.tune),
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          const CustomizeHomeScreen(),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 18),
                          TextField(
                            onChanged: (v) {
                              setState(() {
                                query = v.trim().toLowerCase();
                              });
                            },
                            decoration: InputDecoration(
                              hintText: 'ابحث عن عملة...',
                              prefixIcon: const Icon(Icons.search),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                            ),
                          ),
                          const SizedBox(height: 18),
                          Text(
                            'السوق الموازي 🔥',
                            style: Theme.of(context)
                                .textTheme
                                .headlineSmall
                                ?.copyWith(
                                  fontWeight: FontWeight.w800,
                                ),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'اضغط على العملة لعرض الرسم البياني والتفاصيل',
                          ),
                        ],
                      ),
                    ),
                  ),
                  StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                    stream: FirebaseFirestore.instance
                        .collection('currencies')
                        .orderBy('code')
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (snapshot.hasError) {
                        return SliverFillRemaining(
                          child: Center(
                            child: Text(
                              'تعذر تحميل الأسعار: ${snapshot.error}',
                            ),
                          ),
                        );
                      }

                      if (!snapshot.hasData) {
                        return SliverPadding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 18,
                          ),
                          sliver: SliverList.builder(
                            itemCount: 5,
                            itemBuilder: (_, __) => const Padding(
                              padding: EdgeInsets.only(bottom: 10),
                              child: _LoadingCard(),
                            ),
                          ),
                        );
                      }

                      final currencies = snapshot.data!.docs
                          .map(
                            (doc) => Currency.fromMap(
                              doc.id,
                              doc.data(),
                            ),
                          )
                          .where(
                            (c) => !hidden.contains(c.code),
                          )
                          .where(
                            (c) =>
                                query.isEmpty ||
                                c.code.toLowerCase().contains(query) ||
                                c.name.toLowerCase().contains(query),
                          )
                          .toList();

                      if (currencies.isEmpty) {
                        return const SliverFillRemaining(
                          child: Center(
                            child: Text('لا توجد عملات مطابقة'),
                          ),
                        );
                      }

                      return SliverPadding(
                        padding: const EdgeInsets.fromLTRB(
                          18,
                          0,
                          18,
                          28,
                        ),
                        sliver: SliverList.separated(
                          itemCount: currencies.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 10),
                          itemBuilder: (_, index) {
                            final c = currencies[index];

                            return CurrencyCard(
                              currency: c,
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => CurrencyDetailScreen(
                                      code: c.code,

                                      // FIX:
                                      // Currency -> Map<String, dynamic>
                                      initialData: c.toMap(),
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _LoadingCard extends StatelessWidget {
  const _LoadingCard();

  @override
  Widget build(BuildContext context) => Card(
        child: SizedBox(
          height: 92,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                const CircleAvatar(radius: 25),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      SizedBox(height: 14, width: 130),
                      SizedBox(height: 8),
                      SizedBox(height: 10, width: 80),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}