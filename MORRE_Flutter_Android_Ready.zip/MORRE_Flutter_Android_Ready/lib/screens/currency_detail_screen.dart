import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../models/price_history_point.dart';
import '../services/price_history_service.dart';

class CurrencyDetailScreen extends StatefulWidget {
  final String code;
  final Map<String, dynamic> initialData;

  const CurrencyDetailScreen({
    super.key,
    required this.code,
    required this.initialData,
  });

  @override
  State<CurrencyDetailScreen> createState() => _CurrencyDetailScreenState();
}

class _CurrencyDetailScreenState extends State<CurrencyDetailScreen> {
  ChartRange range = ChartRange.d1;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('currencies')
          .doc(widget.code)
          .snapshots(),
      builder: (context, snapshot) {
        final data = snapshot.data?.data() ?? widget.initialData;

        final buy =
            ((data['parallelBuy'] ?? data['buy'] ?? 0) as num).toDouble();

        final sell =
            ((data['parallelSell'] ?? data['sell'] ?? 0) as num).toDouble();

        final name = data['name']?.toString() ?? widget.code;

        return Scaffold(
          appBar: AppBar(
            title: Text(widget.code),
            actions: [
              IconButton(
                icon: const Icon(Icons.star_border),
                onPressed: () {},
              ),
              IconButton(
                icon: const Icon(Icons.notifications_none),
                onPressed: () {},
              ),
            ],
          ),
          body: StreamBuilder<List<PriceHistoryPoint>>(
            stream: PriceHistoryService.instance.watch(
              widget.code,
              range,
            ),
            builder: (context, historySnapshot) {
              final history = historySnapshot.data ?? [];

              final current =
                  history.isNotEmpty ? history.last.price : sell;

              final previous = history.length > 1
                  ? history[history.length - 2].price
                  : current;

              final delta = current - previous;

              final percent =
                  previous == 0 ? 0 : (delta / previous) * 100;

              final positive = delta >= 0;

              final prices = history.map((e) => e.price).toList();

              final high = prices.isEmpty
                  ? current
                  : prices.reduce(
                      (a, b) => a > b ? a : b,
                    );

              final low = prices.isEmpty
                  ? current
                  : prices.reduce(
                      (a, b) => a < b ? a : b,
                    );

              return ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                children: [
                  Text(
                    name,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${current.toStringAsFixed(2)} SDG',
                    style: Theme.of(context)
                        .textTheme
                        .displaySmall
                        ?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Icon(
                        positive
                            ? Icons.arrow_drop_up
                            : Icons.arrow_drop_down,
                        color: positive ? Colors.green : Colors.red,
                      ),
                      Text(
                        '${delta >= 0 ? '+' : ''}'
                        '${delta.toStringAsFixed(2)} '
                        '(${percent.toStringAsFixed(2)}%)',
                        style: TextStyle(
                          color: positive ? Colors.green : Colors.red,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 10),
                      const Text('آخر تحديث مباشر'),
                    ],
                  ),
                  const SizedBox(height: 22),
                  _TradingChart(
                    history: history,
                    positive: positive,
                  ),
                  const SizedBox(height: 10),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: ChartRange.values.map((item) {
                        final selected = item == range;

                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(item.label),
                            selected: selected,
                            onSelected: (_) {
                              setState(() {
                                range = item;
                              });
                            },
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 22),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _statRow(
                            'شراء',
                            buy.toStringAsFixed(2),
                          ),
                          const Divider(),
                          _statRow(
                            'بيع',
                            sell.toStringAsFixed(2),
                          ),
                          const Divider(),
                          _statRow(
                            '${range.label} High',
                            high.toStringAsFixed(2),
                          ),
                          const Divider(),
                          _statRow(
                            '${range.label} Low',
                            low.toStringAsFixed(2),
                          ),
                          const Divider(),
                          _statRow(
                            'التغير',
                            '${percent >= 0 ? '+' : ''}'
                            '${percent.toStringAsFixed(2)}%',
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.add_alert),
                    label: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 14),
                      child: Text('إنشاء تنبيه سعر'),
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }

  Widget _statRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label),
        Text(
          value,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}

class _TradingChart extends StatelessWidget {
  final List<PriceHistoryPoint> history;
  final bool positive;

  const _TradingChart({
    required this.history,
    required this.positive,
  });

  @override
  Widget build(BuildContext context) {
    if (history.length < 2) {
      return Container(
        height: 280,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: Theme.of(context).dividerColor,
          ),
        ),
        child: const Text(
          'يتم جمع بيانات تاريخ الأسعار للرسم البياني...',
        ),
      );
    }

    final spots = List.generate(
      history.length,
      (i) => FlSpot(
        i.toDouble(),
        history[i].price,
      ),
    );

    final values = history.map((e) => e.price);

    final minYRaw = values.reduce(
      (a, b) => a < b ? a : b,
    );

    final maxYRaw = values.reduce(
      (a, b) => a > b ? a : b,
    );

    final padding =
        ((maxYRaw - minYRaw).abs() * 0.12)
            .clamp(1.0, double.infinity);

    return SizedBox(
      height: 300,
      child: LineChart(
        LineChartData(
          minX: 0,
          maxX: (history.length - 1).toDouble(),
          minY: minYRaw - padding,
          maxY: maxYRaw + padding,
          lineTouchData: LineTouchData(
            enabled: true,
            touchTooltipData: LineTouchTooltipData(
              getTooltipItems: (spots) {
                return spots.map((spot) {
                  final point = history[spot.x.toInt()];

                  return LineTooltipItem(
                    '${point.price.toStringAsFixed(2)} SDG\n'
                    '${point.timestamp.day}/'
                    '${point.timestamp.month} '
                    '${point.timestamp.hour.toString().padLeft(2, '0')}:'
                    '${point.timestamp.minute.toString().padLeft(2, '0')}',
                    Theme.of(context)
                        .textTheme
                        .bodySmall!,
                  );
                }).toList();
              },
            ),
          ),
          gridData: const FlGridData(
            show: true,
            drawVerticalLine: false,
          ),
          titlesData: const FlTitlesData(
            topTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            rightTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
          ),
          borderData: FlBorderData(show: false),
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              barWidth: 3,
              dotData: const FlDotData(show: false),
              belowBarData: BarAreaData(show: true),
            ),
          ],
        ),
        duration: const Duration(milliseconds: 350),
      ),
    );
  }
}