import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'services/auth_service.dart';
import 'services/notification_service.dart';
import 'services/push_notification_service.dart';
import 'services/preferences_service.dart';

import 'screens/home_screen.dart';
import 'screens/converter_screen.dart';
import 'screens/favorites_screen.dart';
import 'screens/alerts_screen.dart';
import 'screens/settings/settings_screen.dart';

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(
  RemoteMessage message,
) async {
  await Firebase.initializeApp();
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp();

  FirebaseMessaging.onBackgroundMessage(
    firebaseMessagingBackgroundHandler,
  );

  runApp(const MorreApp());
}

class MorreApp extends StatefulWidget {
  const MorreApp({super.key});

  @override
  State<MorreApp> createState() => _MorreAppState();
}

class _MorreAppState extends State<MorreApp> {
  ThemeMode themeMode = ThemeMode.system;
  Locale locale = const Locale('ar');

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MORRE',

      locale: locale,

      supportedLocales: const [
        Locale('ar'),
        Locale('en'),
      ],

      // مهم جدًا لـ MaterialLocalizations
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],

      themeMode: themeMode,

      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2563EB),
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
      ),

      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFF60A5FA),
      ),

      home: AppStartup(
        themeMode: themeMode,
        locale: locale,
        onThemeChanged: (value) {
          setState(() {
            themeMode = value;
          });
        },
        onLocaleChanged: (value) {
          setState(() {
            locale = value;
          });
        },
      ),
    );
  }
}

class AppStartup extends StatefulWidget {
  final ThemeMode themeMode;
  final Locale locale;
  final ValueChanged<ThemeMode> onThemeChanged;
  final ValueChanged<Locale> onLocaleChanged;

  const AppStartup({
    super.key,
    required this.themeMode,
    required this.locale,
    required this.onThemeChanged,
    required this.onLocaleChanged,
  });

  @override
  State<AppStartup> createState() => _AppStartupState();
}

class _AppStartupState extends State<AppStartup> {
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    if (!mounted) return;

    setState(() {
      loading = true;
      error = null;
    });

    try {
      await AuthService.instance
          .ensureAnonymousUser()
          .timeout(const Duration(seconds: 20));

      await AuthService.instance
          .initializeGoogle()
          .timeout(const Duration(seconds: 10));

      await PreferencesService.instance
          .initialize()
          .timeout(const Duration(seconds: 15));

      await NotificationService.instance
          .initialize()
          .timeout(const Duration(seconds: 10));

      await PushNotificationService.instance
          .initialize()
          .timeout(const Duration(seconds: 15));

      if (!mounted) return;

      setState(() {
        loading = false;
        error = null;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        loading = false;
        error = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/icon.png',
                  width: 110,
                  height: 110,
                  errorBuilder: (_, __, ___) {
                    return const Icon(
                      Icons.currency_exchange,
                      size: 90,
                    );
                  },
                ),
                const SizedBox(height: 30),
                const Text(
                  'MORRE',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'جاري تشغيل التطبيق...',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                const CircularProgressIndicator(),
              ],
            ),
          ),
        ),
      );
    }

    if (error != null) {
      return Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.error_outline,
                  size: 70,
                ),
                const SizedBox(height: 20),
                const Text(
                  'تعذر تشغيل التطبيق',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 12),
                const Text(
                  'تأكد من اتصال الإنترنت ثم حاول مرة أخرى.',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                Text(
                  error!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 24),
                FilledButton.icon(
                  onPressed: _initialize,
                  icon: const Icon(Icons.refresh),
                  label: const Text('إعادة المحاولة'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return MainShell(
      themeMode: widget.themeMode,
      locale: widget.locale,
      onThemeChanged: widget.onThemeChanged,
      onLocaleChanged: widget.onLocaleChanged,
    );
  }
}

class MainShell extends StatefulWidget {
  final ThemeMode themeMode;
  final Locale locale;
  final ValueChanged<ThemeMode> onThemeChanged;
  final ValueChanged<Locale> onLocaleChanged;

  const MainShell({
    super.key,
    required this.themeMode,
    required this.locale,
    required this.on