import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'services/auth_service.dart';
import 'services/notification_service.dart';
import 'services/push_notification_service.dart';
import 'services/preferences_service.dart';
import 'screens/home_screen.dart';
import 'screens/converter_screen.dart';
import 'screens/favorites_screen.dart';
import 'screens/alerts_screen.dart';
import 'screens/settings/settings_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await AuthService.instance.ensureAnonymousUser();
  await AuthService.instance.initializeGoogle();
  await PreferencesService.instance.initialize();
  await NotificationService.instance.initialize();
  await PushNotificationService.instance.initialize();
  runApp(const MorreApp());
}

class MorreApp extends StatefulWidget {
  const MorreApp({super.key});
  @override
  State<MorreApp> createState() => _MorreAppState();
}

class _MorreAppState extends State<MorreApp> {
  ThemeMode themeMode = ThemeMode.system;
  Locale locale = const Locale('ar');

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MORRE',
      locale: locale,
      supportedLocales: const [Locale('ar'), Locale('en')],
      themeMode: themeMode,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2563EB),
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFF60A5FA),
      ),
      home: MainShell(
        themeMode: themeMode,
        locale: locale,
        onThemeChanged: (value) => setState(() => themeMode = value),
        onLocaleChanged: (value) => setState(() => locale = value),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  final ThemeMode themeMode;
  final Locale locale;
  final ValueChanged<ThemeMode> onThemeChanged;
  final ValueChanged<Locale> onLocaleChanged;

  const MainShell({
    super.key,
    required this.themeMode,
    required this.locale,
    required this.onThemeChanged,
    required this.onLocaleChanged,
  });

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomeScreen(),
      const ConverterScreen(),
      const FavoritesScreen(),
      const AlertsScreen(),
      SettingsScreen(
        themeMode: widget.themeMode,
        locale: widget.locale,
        onThemeChanged: widget.onThemeChanged,
        onLocaleChanged: widget.onLocaleChanged,
      ),
    ];

    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.currency_exchange_outlined), selectedIcon: Icon(Icons.currency_exchange), label: 'المحول'),
          NavigationDestination(icon: Icon(Icons.star_outline), selectedIcon: Icon(Icons.star), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.notifications_outlined), selectedIcon: Icon(Icons.notifications), label: 'التنبيهات'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'الإعدادات'),
        ],
      ),
    );
  }
}
