class Currency {
  final String id;
  final String code;
  final String name;
  final String flag;
  final double officialBuy;
  final double officialSell;
  final double parallelBuy;
  final double parallelSell;
  final double changePercent;

  const Currency({
    required this.id,
    required this.code,
    required this.name,
    required this.flag,
    required this.officialBuy,
    required this.officialSell,
    required this.parallelBuy,
    required this.parallelSell,
    required this.changePercent,
  });

  static double _number(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse(value?.toString() ?? '') ?? 0;
  }

  factory Currency.fromMap(String id, Map<String, dynamic> data) {
    final official = Map<String, dynamic>.from(
      data['official'] is Map ? data['official'] as Map : const {},
    );
    final parallel = Map<String, dynamic>.from(
      data['parallel'] is Map ? data['parallel'] as Map : const {},
    );

    return Currency(
      id: id,
      code: (data['code'] ?? id).toString().toUpperCase(),
      name: (data['nameAr'] ?? data['name'] ?? id).toString(),
      flag: (data['flag'] ?? '💱').toString(),
      officialBuy: _number(official['buy'] ?? data['officialBuy'] ?? data['buy']),
      officialSell: _number(official['sell'] ?? data['officialSell'] ?? data['sell']),
      parallelBuy: _number(parallel['buy'] ?? data['parallelBuy']),
      parallelSell: _number(parallel['sell'] ?? data['parallelSell']),
      changePercent: _number(data['changePercent']),
    );
  }
}
