import 'package:cloud_firestore/cloud_firestore.dart';

class PriceHistoryPoint {
  final double price;
  final double buy;
  final double sell;
  final DateTime timestamp;

  const PriceHistoryPoint({
    required this.price,
    required this.buy,
    required this.sell,
    required this.timestamp,
  });

  static double _number(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse(value?.toString() ?? '') ?? 0;
  }

  factory PriceHistoryPoint.fromFirestore(
    DocumentSnapshot<Map<String, dynamic>> doc,
  ) {
    final data = doc.data() ?? {};
    final rawTime = data['timestamp'];
    return PriceHistoryPoint(
      price: _number(data['price'] ?? data['sell']),
      buy: _number(data['buy'] ?? data['parallelBuy']),
      sell: _number(data['sell'] ?? data['parallelSell']),
      timestamp: rawTime is Timestamp ? rawTime.toDate() : DateTime.now(),
    );
  }
}
