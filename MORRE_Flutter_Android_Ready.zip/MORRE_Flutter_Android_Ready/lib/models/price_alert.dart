import 'package:cloud_firestore/cloud_firestore.dart';

class PriceAlert {
  final String id;
  final String currencyCode;
  final double targetPrice;
  final String market;
  final String type;
  final bool enabled;
  final DateTime createdAt;

  const PriceAlert({
    required this.id,
    required this.currencyCode,
    required this.targetPrice,
    required this.market,
    required this.type,
    required this.enabled,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'currencyCode': currencyCode,
        'targetPrice': targetPrice,
        'market': market,
        'type': type,
        'enabled': enabled,
      };

  factory PriceAlert.fromMap(String id, Map<String, dynamic> map) {
    final rawDate = map['createdAt'];
    final createdAt = rawDate is Timestamp
        ? rawDate.toDate()
        : DateTime.tryParse(map['createdAtClient']?.toString() ?? '') ?? DateTime.now();

    final rawTarget = map['targetPrice'];
    final target = rawTarget is num
        ? rawTarget.toDouble()
        : double.tryParse(rawTarget?.toString() ?? '') ?? 0;

    return PriceAlert(
      id: id,
      currencyCode: map['currencyCode']?.toString() ?? '',
      targetPrice: target,
      market: map['market']?.toString() == 'official' ? 'official' : 'parallel',
      type: map['type']?.toString() == 'below' ? 'below' : 'above',
      enabled: map['enabled'] != false,
      createdAt: createdAt,
    );
  }
}
