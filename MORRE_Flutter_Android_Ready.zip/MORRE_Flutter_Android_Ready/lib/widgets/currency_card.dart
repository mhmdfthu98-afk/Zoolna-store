import 'package:flutter/material.dart';
import '../models/currency.dart';
import '../services/preferences_service.dart';

class CurrencyCard extends StatefulWidget {
  final Currency currency;
  final VoidCallback? onTap;
  const CurrencyCard({super.key, required this.currency, this.onTap});

  @override
  State<CurrencyCard> createState() => _CurrencyCardState();
}

class _CurrencyCardState extends State<CurrencyCard> {
  bool favorite = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result = await PreferencesService.instance.isFavorite(widget.currency.code);
    if (mounted) setState(() => favorite = result);
  }

  Future<void> _toggleFavorite() async {
    await PreferencesService.instance.toggleFavorite(widget.currency.code);
    if (mounted) setState(() => favorite = !favorite);
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.currency;
    final positive = c.changePercent > 0;
    final negative = c.changePercent < 0;
    final changeColor = positive ? Colors.green : negative ? Colors.red : Colors.grey;

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: widget.onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            Text(c.flag, style: const TextStyle(fontSize: 30)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(c.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              const SizedBox(height: 3),
              Text(c.code, style: Theme.of(context).textTheme.bodySmall),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text('${c.parallelBuy.toStringAsFixed(0)} / ${c.parallelSell.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Row(children: [
                Icon(positive ? Icons.trending_up : negative ? Icons.trending_down : Icons.remove, size: 16, color: changeColor),
                const SizedBox(width: 3),
                Text('${c.changePercent >= 0 ? '+' : ''}${c.changePercent.toStringAsFixed(2)}%', style: TextStyle(color: changeColor)),
              ]),
            ]),
            IconButton(
              tooltip: favorite ? 'إزالة من المفضلة' : 'إضافة للمفضلة',
              onPressed: _toggleFavorite,
              icon: Icon(favorite ? Icons.star : Icons.star_border, color: favorite ? Colors.amber : null),
            ),
            const Icon(Icons.chevron_right),
          ]),
        ),
      ),
    );
  }
}
