MORRE Android platform files

IMPORTANT FIREBASE STEP:
1) Download google-services.json from Firebase Console for package:
   com.morre.morre_flutter
2) Put it exactly here:
   android/app/google-services.json
3) In Firebase Authentication enable Anonymous, Email/Password and Google.
4) For Google Sign-In add SHA-1 and SHA-256 for this Android app.

Then run from the Flutter project root:
flutter pub get
flutter build apk --debug

APK output:
build/app/outputs/flutter-apk/app-debug.apk

For release:
flutter build apk --release
