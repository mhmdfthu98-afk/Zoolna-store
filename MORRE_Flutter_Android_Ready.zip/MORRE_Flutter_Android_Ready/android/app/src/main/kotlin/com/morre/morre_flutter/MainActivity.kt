package com.morre.morre_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
