# MORRE Phase 16 — Trading Style Currency Details

## تمت إضافته
- صفحة تفاصيل احترافية لكل عملة.
- تصميم مستوحى من واجهات التداول والعملات الرقمية.
- السعر الحالي.
- مقدار ونسبة التغير.
- رسم Line Chart تفاعلي باستخدام fl_chart.
- لمس الرسم لعرض السعر والتاريخ.
- فترات: 1H / 1D / 1W / 1M / 3M / 1Y / ALL.
- High / Low.
- Buy / Sell.
- زر إنشاء تنبيه.

## Firebase History
المسار:
currencies/{CODE}/history/{AUTO_ID}

الحقول:
- price
- buy
- sell
- timestamp

## مهم للوحة التحكم
كل مرة يتم فيها تغيير سعر العملة يجب تسجيل نسخة في history.
يوجد:
PriceHistoryService.instance.recordPrice(...)

يفضل استدعاؤه داخل عملية تحديث السعر في Admin Dashboard أو Cloud Function.
بهذا يصبح الرسم البياني حقيقياً ويستمر في بناء تاريخ الأسعار.

## Dependency
تمت إضافة:
fl_chart: ^0.69.0

شغّل:
flutter pub get

## المرحلة المستقبلية
يمكن إضافة Candlestick Chart حقيقي إذا توفرت بيانات OHLC
(open/high/low/close) لكل فترة زمنية.