# MORRE Flutter - Phase 9: Firebase Authentication + Security

## ما تم إضافته

- Firebase Authentication.
- تسجيل دخول Anonymous تلقائي عند أول تشغيل.
- UID حقيقي لكل مستخدم.
- نقل التنبيهات إلى users/{uid}/alerts.
- نقل أجهزة المستخدم إلى users/{uid}/devices.
- حفظ FCM Token تحت حساب المستخدم.
- تحديث Cloud Function للبنية الجديدة.
- Firestore Security Rules تمنع المستخدم من قراءة بيانات مستخدم آخر.

## البنية الجديدة

users
 └── UID
      ├── alerts
      │    └── alertId
      └── devices
           └── FCM_TOKEN

currencies
 └── USD

## لماذا Anonymous Auth؟

المستخدم لا يحتاج تسجيل بريد أو كلمة مرور الآن، لكنه يحصل على Firebase UID آمن.
لاحقاً يمكن إضافة:
- Google Sign In
- Email/Password
- Phone Authentication

## إعداد Firebase

من Firebase Console:
Authentication
→ Sign-in method
→ Anonymous
→ Enable

ثم:

flutter pub get
flutterfire configure
flutter run

نشر القواعد:

firebase deploy --only firestore:rules

نشر الوظائف:

cd functions
npm install
cd ..
firebase deploy --only functions

## النتيجة

كل مستخدم يرى تنبيهاته فقط، وCloud Functions تعمل على السحابة وترسل
الإشعارات حتى لو التطبيق مغلق.