# MORRE Flutter - Phase 11: Google Sign-In

## ما تم إضافته

- تسجيل الدخول باستخدام Google.
- ربط حساب Google بالحساب Anonymous الحالي.
- الحفاظ على نفس Firebase UID والتنبيهات عند الربط.
- إمكانية تسجيل الدخول من هاتف آخر بحساب Google.
- إضافة زر Google داخل شاشة تسجيل الدخول.
- إضافة خيار ربط Google داخل صفحة الحساب.

## إعداد Firebase

Firebase Console
→ Authentication
→ Sign-in method
→ Google
→ Enable

## Android

أضف SHA-1 و SHA-256 للتطبيق داخل Firebase Project Settings.
بعد ذلك أعد تنزيل google-services.json وضعه داخل:

android/app/google-services.json

ثم نفّذ:

flutterfire configure
flutter pub get
flutter run

## تدفق المستخدم

مستخدم ضيف
  ↓
إضافة تنبيهات
  ↓
تسجيل الدخول بـ Google
  ↓
ربط Credential بالحساب الحالي
  ↓
نفس UID
  ↓
نفس التنبيهات
  ↓
تغيير الهاتف
  ↓
تسجيل الدخول بنفس Google
  ↓
استرجاع البيانات

## ملاحظة

إذا كان حساب Google مستخدمًا مسبقًا مع حساب Firebase مختلف،
قد تحتاج إلى معالجة credential-already-in-use أو تسجيل الدخول للحساب
الموجود بدل محاولة الربط.