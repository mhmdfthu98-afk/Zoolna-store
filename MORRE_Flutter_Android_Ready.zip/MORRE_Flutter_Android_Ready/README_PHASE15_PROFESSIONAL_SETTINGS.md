# MORRE Phase 15 — Professional Settings

## تمت إضافة
- صفحة إعدادات رئيسية منظمة.
- المظهر: فاتح / داكن / حسب الجهاز.
- اللغة: العربية / الإنجليزية.
- إعدادات الإشعارات.
- تشغيل/إيقاف تنبيهات الأسعار.
- تحديثات السوق والإشعارات العامة.
- الصوت والاهتزاز.
- إدارة الحساب.
- إرسال رابط إعادة تعيين كلمة المرور.
- تسجيل الخروج.
- صفحة حول التطبيق.

## Firebase
الإعدادات تحفظ في:
users/{uid}/settings/preferences

وتشمل:
themeMode
language
notifications
hiddenCurrencies

## ملاحظة دمج مهمة
واجهات الإعدادات تعمل وتحفظ القيم في Firestore.
لتطبيق تغيير Theme وLocale فورياً على MaterialApp في كامل المشروع، يوصى بربط
AppSettingsProvider مع نقطة main.dart باستخدام ChangeNotifier/Provider أو ValueNotifier.
تم إنشاء AppSettingsProvider كأساس لهذا الربط.

## لا يتم حذف الحساب في هذه المرحلة
حذف الحساب يحتاج Cloud Function أو إعادة مصادقة آمنة، لذلك لم يتم وضع زر حذف غير مكتمل.