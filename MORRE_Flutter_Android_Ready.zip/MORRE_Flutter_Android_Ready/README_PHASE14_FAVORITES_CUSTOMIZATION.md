# MORRE Phase 14 — Favorites, Ordering & Personalized Home

## تمت إضافة

### ⭐ المفضلة
- إضافة/إزالة العملة من المفضلة.
- حفظ المفضلة لكل مستخدم في Firebase.
- صفحة مفضلة حقيقية.

### 📌 التثبيت
- تثبيت العملات المهمة.
- قاعدة البيانات تحفظ pinned: true/false.

### 🔄 ترتيب بالسحب
- ReorderableListView.
- حفظ ترتيب العملات في Firestore.

### 🎨 تخصيص الرئيسية
- إخفاء العملات التي لا يريد المستخدم رؤيتها.
- إعادة الإعدادات الافتراضية.
- زر تخصيص داخل الصفحة الرئيسية.

## Firestore Structure

users/{uid}/favorites/{currencyCode}
- code
- order
- pinned
- createdAt

users/{uid}/settings/preferences
- hiddenCurrencies
- updatedAt

## قواعد Firestore
تمت إضافة صلاحيات favorites وsettings بحيث لا يستطيع أي مستخدم قراءة أو تعديل إعدادات مستخدم آخر.

## ملاحظة
يفضل دمج ترتيب pinned + favorites بشكل كامل في Home بعد اكتمال صفحة تفاصيل العملات، لأن المرحلة التالية يمكن أن تضيف محرك ترتيب موحد:
Pinned → Favorites → Remaining currencies.