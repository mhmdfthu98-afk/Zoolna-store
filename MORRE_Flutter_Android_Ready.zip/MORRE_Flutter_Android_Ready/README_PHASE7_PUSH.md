# MORRE Flutter - Phase 7: Push Notifications When App Is Closed

## الجديد

- Firebase Cloud Messaging (FCM)
- حفظ FCM Token لكل جهاز
- نقل التنبيهات إلى Firestore
- Firebase Cloud Function تعمل على السحابة
- فحص التنبيهات عند تغير وثيقة العملة
- إرسال Push Notification حتى لو التطبيق مغلق
- منع تكرار الإشعار لنفس السعر

## هيكل Firestore

currencies/{USD}
devices/{deviceId}
devices/{deviceId}/alerts/{alertId}

## إعداد Firebase CLI

ثبّت Firebase CLI ثم:

npm install -g firebase-tools
firebase login
firebase init functions
firebase use YOUR_PROJECT_ID

داخل functions:

npm install

ثم النشر:

firebase deploy --only functions

## Flutter

flutter pub get
flutterfire configure
flutter run

## مهم

لكي تعمل الإشعارات والتطبيق مغلق:
1. يجب تفعيل Firebase Cloud Messaging.
2. يجب نشر Cloud Function.
3. يجب أن يكون الهاتف متصلاً بالإنترنت.
4. في بعض أجهزة Android ذات أنظمة توفير البطارية القوية، يجب السماح للتطبيق بالإشعارات وعدم تقييده بشدة.

## ملاحظة هندسية

الكود السابق كان يراقب الأسعار داخل Flutter، وهذا يتوقف عند إغلاق التطبيق.
هذه المرحلة تنقل قرار إرسال الإشعار إلى Firebase Cloud Functions، لذلك لا يعتمد على بقاء التطبيق مفتوحاً.