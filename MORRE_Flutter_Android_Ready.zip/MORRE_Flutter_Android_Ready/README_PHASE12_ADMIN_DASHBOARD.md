# MORRE Phase 12 — Admin Dashboard + Broadcast Notifications

## الجديد
- Flutter Web Admin Dashboard داخل `admin_dashboard/`.
- دخول Email/Password وحظر أي بريد غير بريد المدير المحدد.
- إضافة/تعديل/حذف العملات والأسعار الرسمية والموازية.
- تحديث Firestore مباشرة، فتظهر الأسعار فوراً في تطبيق MORRE.
- Callable Cloud Function آمنة لإرسال إشعار Broadcast.
- Firebase Cloud Messaging يصل للهاتف حتى لو التطبيق مغلق.
- سجل `notifications_log` لنتائج الإرسال.

## إعداد Firebase
1. فعّل Email/Password في Firebase Authentication.
2. أنشئ حساب المدير بالبريد المحدد في الكود.
3. من `admin_dashboard`: شغّل `flutterfire configure` واختر نفس مشروع Firebase.
4. `flutter pub get`
5. اختبار الويب: `flutter run -d chrome`

## النشر
لوحة التحكم:
```
cd admin_dashboard
flutter build web --release
cd ..
firebase deploy --only hosting
```

القواعد والوظائف:
```
cd functions
npm install
cd ..
firebase deploy --only functions,firestore:rules
```

## تدفق الإشعار
Admin Dashboard → sendBroadcastNotification → فحص صلاحية المدير → قراءة FCM Tokens → FCM → هواتف المستخدمين → notifications_log
