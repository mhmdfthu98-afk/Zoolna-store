const { onDocumentUpdated } = require('firebase-functions/v2/firestore');
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { logger } = require('firebase-functions');
const admin = require('firebase-admin');

admin.initializeApp();
const db = admin.firestore();
const messaging = admin.messaging();
const ADMIN_EMAIL = 'mhmdfthu98@gmail.com';

function priceFor(currency, market, type) {
  const official = market === 'official';
  const above = type !== 'below';
  const key = official ? (above ? 'officialSell' : 'officialBuy') : (above ? 'parallelSell' : 'parallelBuy');
  return Number(currency[key] || 0);
}

exports.recordCurrencyPriceHistory = onDocumentUpdated(
  { document: 'currencies/{currencyCode}', region: 'us-central1' },
  async (event) => {
    const before = event.data.before.data() || {};
    const after = event.data.after.data() || {};
    const keys = ['officialBuy', 'officialSell', 'parallelBuy', 'parallelSell'];
    if (!keys.some((key) => before[key] !== after[key])) return;
    await db.collection('currencies').doc(event.params.currencyCode).collection('history').add({
      price: Number(after.parallelSell ?? after.sell ?? 0),
      buy: Number(after.parallelBuy ?? after.buy ?? 0),
      sell: Number(after.parallelSell ?? after.sell ?? 0),
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      source: 'cloud_function',
      updatedBy: after.updatedBy ?? null,
    });
  },
);

exports.checkPriceAlerts = onDocumentUpdated(
  { document: 'currencies/{currencyCode}', region: 'us-central1' },
  async (event) => {
    const currency = event.data.after.data();
    const currencyCode = event.params.currencyCode;
    const users = await db.collection('users').get();
    const jobs = [];

    for (const userDoc of users.docs) {
      const alerts = await userDoc.ref.collection('alerts').where('currencyCode', '==', currencyCode).where('enabled', '==', true).get();
      if (alerts.empty) continue;
      const devices = await userDoc.ref.collection('devices').get();
      const tokens = devices.docs.map((d) => d.data().fcmToken).filter(Boolean);
      if (!tokens.length) continue;

      for (const alertDoc of alerts.docs) {
        const alert = alertDoc.data();
        const market = alert.market === 'official' ? 'official' : 'parallel';
        const type = alert.type === 'below' ? 'below' : 'above';
        const price = priceFor(currency, market, type);
        const target = Number(alert.targetPrice || 0);
        if (!price || !target) continue;
        const triggered = type === 'above' ? price >= target : price <= target;
        if (!triggered) continue;

        const stateRef = alertDoc.ref.collection('state').doc('latest');
        const stateSnap = await stateRef.get();
        const state = stateSnap.exists ? stateSnap.data() : {};
        const signature = `${price.toFixed(4)}:${target}:${market}:${type}`;
        if (state.lastSignature === signature) continue;

        const title = `تنبيه سعر ${currencyCode}`;
        const body = type === 'above' ? `وصل السعر إلى ${price.toFixed(2)} وتجاوز ${target.toFixed(2)}` : `وصل السعر إلى ${price.toFixed(2)} وتحت ${target.toFixed(2)}`;
        for (let i = 0; i < tokens.length; i += 500) {
          const chunk = tokens.slice(i, i + 500);
          jobs.push(messaging.sendEachForMulticast({
            tokens: chunk,
            notification: { title, body },
            android: { priority: 'high', notification: { channelId: 'morre_push_alerts', sound: 'default' } },
            data: { type: 'price_alert', currencyCode, alertId: alertDoc.id },
          }).then(() => stateRef.set({ lastSignature: signature, lastSentAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true })));
        }
      }
    }
    await Promise.all(jobs);
    logger.info(`Price alert check complete for ${currencyCode}`);
  },
);

exports.sendBroadcastNotification = onCall({ region: 'us-central1' }, async (request) => {
  if (!request.auth || request.auth.token.email !== ADMIN_EMAIL) throw new HttpsError('permission-denied', 'Admin only');
  const title = String(request.data?.title || '').trim();
  const body = String(request.data?.body || '').trim();
  if (!title || !body) throw new HttpsError('invalid-argument', 'Title and body are required');

  const users = await db.collection('users').get();
  const tokens = [];
  for (const user of users.docs) {
    const devices = await user.ref.collection('devices').get();
    for (const device of devices.docs) {
      const token = device.data().fcmToken;
      if (token) tokens.push(token);
    }
  }

  let successCount = 0;
  let failureCount = 0;
  for (let i = 0; i < tokens.length; i += 500) {
    const chunk = tokens.slice(i, i + 500);
    const result = await messaging.sendEachForMulticast({
      tokens: chunk,
      notification: { title, body },
      android: { priority: 'high', notification: { channelId: 'morre_push_alerts', sound: 'default' } },
      data: { type: 'admin_broadcast' },
    });
    successCount += result.successCount;
    failureCount += result.failureCount;
  }

  await db.collection('notifications_log').add({
    title, body, target: 'all', successCount, failureCount,
    sentBy: request.auth.token.email,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });
  return { success: true, successCount, failureCount };
});
