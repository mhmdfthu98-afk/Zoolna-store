# MORRE Flutter - Phase 8

## الهدف

تم ربط شاشة التنبيهات بالكامل بـ Firebase Firestore بدل SharedPreferences.

الآن المسار:

Flutter App
  ↓
Firestore devices/{deviceId}/alerts
  ↓
Cloud Function
  ↓
Firebase Cloud Messaging
  ↓
Push Notification حتى لو التطبيق مغلق

## ما تم تغييره

- إضافة Device ID محلي ثابت للتطبيق.
- حفظ FCM Token داخل devices/{deviceId}.
- حفظ التنبيهات داخل devices/{deviceId}/alerts.
- شاشة التنبيهات تقرأ مباشرة من Firestore.
- تشغيل/إيقاف التنبيه يحدث مباشرة في Firestore.
- حذف التنبيه يحدث مباشرة في Firestore.
- Cloud Function الموجودة في المرحلة السابقة تستطيع قراءة نفس البنية.

## نشر Firestore Rules

firebase deploy --only firestore:rules

## نشر Cloud Functions

cd functions
npm install
cd ..
firebase deploy --only functions

## تشغيل Flutter

flutter pub get
flutterfire configure
flutter run

## اختبار

1. افتح التطبيق.
2. اسمح بالإشعارات.
3. أضف تنبيه USD.
4. تأكد من ظهوره في Firestore تحت:
   devices/{deviceId}/alerts
5. غيّر سعر USD في currencies/USD.
6. Cloud Function تفحص التنبيه.
7. يصل FCM للهاتف حتى لو التطبيق مغلق.

## ملاحظة أمنية مهمة

القواعد الحالية مناسبة للتجربة فقط لأنها تسمح بالوصول المفتوح.
قبل نشر التطبيق للعامة يجب إضافة Firebase Authentication وربط كل مستخدم
بـ UID ومنع المستخدمين من الوصول إلى بيانات الآخرين.