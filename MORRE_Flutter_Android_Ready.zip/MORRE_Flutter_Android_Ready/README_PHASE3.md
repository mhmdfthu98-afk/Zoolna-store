# MORRE Flutter - Phase 3

تمت إضافة:
- محول عملات يعتمد على بيانات Firebase.
- السوق الرسمي والموازي.
- سعر الشراء والبيع.
- تبديل العملات.
- SharedPreferences جاهز للمفضلة.

شغّل:
flutter pub get
flutterfire configure
flutter run
