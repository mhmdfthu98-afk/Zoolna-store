# MORRE Phase 16 — Automatic Price History from Admin Dashboard

## تم إضافة خدمة مركزية
الملف:
lib/services/admin_price_update_service.dart

الخدمة:
AdminPriceUpdateService.instance.updateCurrencyPrice(...)

هذه الخدمة تقوم بعمليتين داخل Firestore Batch واحد:

1. تحديث السعر الحالي:
currencies/{CODE}

2. إضافة سجل تاريخي:
currencies/{CODE}/history/{AUTO_ID}

## الاستخدام داخل لوحة التحكم

بدلاً من تحديث Firestore مباشرة مثل:

FirebaseFirestore.instance.collection('currencies').doc(code).set({
  'parallelBuy': buy,
  'parallelSell': sell,
}, SetOptions(merge: true));

استخدم:

await AdminPriceUpdateService.instance.updateCurrencyPrice(
  code: code,
  buy: buy.toDouble(),
  sell: sell.toDouble(),
);

## النتيجة

Admin Dashboard
      |
      | تغيير سعر USD
      v
Firestore Batch
      |
      +--> currencies/USD
      |       parallelBuy
      |       parallelSell
      |
      +--> currencies/USD/history/autoId
              price
              buy
              sell
              timestamp

وبذلك كل تعديل جديد يظهر فوراً في التطبيق، ويتم حفظ نقطة جديدة للرسم البياني تلقائياً.

## مهم
إذا كانت لوحة التحكم Flutter Web داخل admin_dashboard بمشروع منفصل،
انسخ نفس الخدمة إلى:

admin_dashboard/lib/services/admin_price_update_service.dart

ثم استوردها في صفحة تعديل العملات.