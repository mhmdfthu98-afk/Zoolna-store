# MORRE Phase 13 — UI/UX Upgrade

تمت إضافة مكونات واجهة حديثة قابلة للدمج:

- Bottom Navigation من 4 أقسام.
- تصميم Home حديث.
- Currency Cards احترافية.
- حالة ارتفاع/انخفاض السعر.
- بحث سريع.
- Pull to Refresh.
- Skeleton Loading.
- Bottom Sheet لتفاصيل العملة.
- Theme جاهز للوضع الفاتح والداكن.

## الملفات الجديدة
- lib/widgets/morre_theme.dart
- lib/widgets/currency_card.dart
- lib/screens/ui_preview_screen.dart

## الدمج
يمكن جعل UiPreviewScreen هي الشاشة الرئيسية تدريجياً:
home: const UiPreviewScreen()

ثم دمج الشاشات الحالية للمفضلة والتنبيهات والحساب داخل الـ Bottom Navigation.

## ملاحظة
تم تصميم المرحلة كترقية UI قابلة للدمج بدون حذف منطق Firebase والتنبيهات الموجود في المراحل السابقة.