# MORRE Flutter — Final Release Candidate

هذه النسخة الموحدة هي المصدر النهائي للمشروع بعد مراجعة البنية وتصحيح التعارضات المكتشفة في المراحل السابقة.

## المزايا المضمنة
- Flutter Android app
- Firebase Authentication: Anonymous + Email/Password + Google
- Firebase Firestore: currencies / history / alerts / favorites / settings / devices
- Firebase Cloud Messaging (FCM)
- Local notifications في الواجهة الأمامية
- Cloud Functions لتنبيه الأسعار والبث العام وتسجيل History
- صفحة تفاصيل العملة مع Trading-style Line Chart
- 1H / 1D / 1W / 1M / 3M / 1Y / ALL
- المفضلة وترتيبها وتخصيص العملات الظاهرة
- إعدادات المظهر واللغة والإشعارات والحساب
- Admin Dashboard بـ Flutter Web لإدارة الأسعار وإرسال الإشعارات

## مدير النظام
البريد المسموح له في لوحة الإدارة:
`mhmdfthu98@gmail.com`

أنشئ هذا البريد كمستخدم Email/Password داخل Firebase Authentication.

## إعداد Firebase للتطبيق
من جذر المشروع:

```bash
flutter pub get
flutterfire configure
flutter run
```

فعّل في Firebase Authentication:
- Anonymous
- Email/Password
- Google

بالنسبة إلى Google Sign-In في Android، أضف SHA-1 وSHA-256 لتطبيق Android في إعدادات Firebase.

## إعداد لوحة الإدارة
```bash
cd admin_dashboard
flutter pub get
flutterfire configure
flutter run -d chrome
```

للنشر:
```bash
flutter build web --release
cd ..
firebase deploy --only hosting
```

## Cloud Functions
```bash
cd functions
npm install
cd ..
firebase deploy --only functions,firestore:rules
```

## تدفق الأسعار والتنبيهات

Admin Dashboard
→ Firestore `currencies/{CODE}`
→ Cloud Function `recordCurrencyPriceHistory`
→ `currencies/{CODE}/history`
→ تطبيق MORRE يقرأ السعر مباشرة

وبالتوازي:

تغيير السعر
→ Cloud Function `checkPriceAlerts`
→ Firebase Cloud Messaging
→ إشعار الهاتف حتى عند إغلاق التطبيق، طالما الجهاز متصل بالشبكة وإشعارات التطبيق مسموحة.

## لماذا لا يوجد API خارجي للأسعار؟
الأسعار تُدار يدويًا من لوحة التحكم كما طلبت، ولا يتم استبدالها بمصدر أسعار خارجي.

## ملاحظات مهمة
- ملفات إعداد Firebase الخاصة بمشروعك مثل `google-services.json` وتهيئة FlutterFire لم أضعها داخل النسخة لأنها مرتبطة بمشروع Firebase الخاص بك.
- هذه الحزمة هي Release Candidate، وليست APK جاهزًا؛ يلزم ربط Firebase ثم تنفيذ البناء على بيئة Flutter الفعلية.
- بيئة العمل الحالية لا تحتوي على Flutter SDK، لذلك لا يمكنني الادعاء بأن `flutter analyze` أو `flutter build apk --release` تم تشغيلهما هنا. أجريت بدل ذلك مراجعة بنيوية، صححت التعارضات الواضحة، وفحصت JavaScript الخاص بـ Cloud Functions باستخدام `node --check`.
- تم توحيد حزم Flutter على خط حديث متوافق مع Dart 3.10+؛ صفحات الحزم الرسمية الحالية تشير إلى Firebase Core 4.14.0 وFirebase Auth 6.6.1 وCloud Firestore 6.9.0 وFCM 16.6.0 وGoogle Sign-In 7.2.0 وfl_chart 1.2.0 وflutter_local_notifications 22.3.0. citeturn360338search5turn976958search4turn276737search5turn976958search5turn360338search8turn276737search0turn276737search1
