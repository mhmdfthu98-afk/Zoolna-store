import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

const adminEmail = 'mhmdfthu98@gmail.com';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MorreAdminApp());
}

class MorreAdminApp extends StatelessWidget {
  const MorreAdminApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'MORRE Admin',
        theme: ThemeData(useMaterial3: true, brightness: Brightness.dark, colorSchemeSeed: Colors.blue),
        home: const AdminGate(),
      );
}

class AdminGate extends StatelessWidget {
  const AdminGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
          final user = snapshot.data;
          if (user == null) return const AdminLoginScreen();
          if (user.email?.toLowerCase() != adminEmail) {
            return Scaffold(body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.block, size: 72, color: Colors.red),
              const SizedBox(height: 12),
              const Text('غير مصرح لك بالدخول'),
              const SizedBox(height: 12),
              OutlinedButton(onPressed: () => FirebaseAuth.instance.signOut(), child: const Text('خروج')),
            ])));
          }
          return const AdminDashboard();
        },
      );
}

class AdminLoginScreen extends StatefulWidget {
  const AdminLoginScreen({super.key});
  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends State<AdminLoginScreen> {
  final email = TextEditingController(text: adminEmail);
  final password = TextEditingController();
  bool loading = false;
  @override
  void dispose() { email.dispose(); password.dispose(); super.dispose(); }
  Future<void> login() async {
    if (email.text.trim().toLowerCase() != adminEmail) return;
    setState(() => loading = true);
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
    } on FirebaseAuthException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'فشل تسجيل الدخول')));
    } finally { if (mounted) setState(() => loading = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(body: Center(child: SizedBox(width: 430, child: Card(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.admin_panel_settings, size: 72),
    const SizedBox(height: 16),
    const Text('MORRE Admin', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
    const SizedBox(height: 24),
    TextField(controller: email, decoration: const InputDecoration(labelText: 'البريد')),
    const SizedBox(height: 12),
    TextField(controller: password, obscureText: true, onSubmitted: (_) => login(), decoration: const InputDecoration(labelText: 'كلمة المرور')),
    const SizedBox(height: 20),
    SizedBox(width: double.infinity, child: FilledButton(onPressed: loading ? null : login, child: Text(loading ? 'جارٍ الدخول...' : 'دخول'))),
  ])))));
}

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});
  @override State<AdminDashboard> createState() => _AdminDashboardState();
}
class _AdminDashboardState extends State<AdminDashboard> {
  int index = 0;
  @override Widget build(BuildContext context) {
    final pages = const [CurrencyManager(), BroadcastPage(), NotificationLogPage()];
    return Scaffold(
      appBar: AppBar(title: const Text('MORRE Admin'), actions: [Text(adminEmail), const SizedBox(width: 12), IconButton(onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout))]),
      body: Row(children: [
        NavigationRail(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v), labelType: NavigationRailLabelType.all, destinations: const [
          NavigationRailDestination(icon: Icon(Icons.currency_exchange), label: Text('الأسعار')),
          NavigationRailDestination(icon: Icon(Icons.campaign), label: Text('الإشعارات')),
          NavigationRailDestination(icon: Icon(Icons.history), label: Text('السجل')),
        ]),
        const VerticalDivider(width: 1), Expanded(child: pages[index]),
      ]),
    );
  }
}

class CurrencyManager extends StatelessWidget {
  const CurrencyManager({super.key});
  Future<void> edit(BuildContext context, DocumentSnapshot<Map<String,dynamic>>? doc) async {
    final d = doc?.data() ?? {};
    final code = TextEditingController(text: doc?.id ?? '');
    final name = TextEditingController(text: '${d['nameAr'] ?? d['name'] ?? ''}');
    final ob = TextEditingController(text: '${d['officialBuy'] ?? 0}');
    final os = TextEditingController(text: '${d['officialSell'] ?? 0}');
    final pb = TextEditingController(text: '${d['parallelBuy'] ?? 0}');
    final ps = TextEditingController(text: '${d['parallelSell'] ?? 0}');
    await showDialog(context: context, builder: (ctx) => AlertDialog(
      title: Text(doc == null ? 'إضافة عملة' : 'تعديل ${doc.id}'),
      content: SizedBox(width: 520, child: SingleChildScrollView(child: Column(children: [
        TextField(controller: code, enabled: doc == null, decoration: const InputDecoration(labelText: 'الرمز')),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم')),
        TextField(controller: ob, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'رسمي شراء')),
        TextField(controller: os, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'رسمي بيع')),
        TextField(controller: pb, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'موازي شراء')),
        TextField(controller: ps, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'موازي بيع')),
      ]))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(onPressed: () async {
          final id = code.text.trim().toUpperCase();
          if (id.isEmpty || name.text.trim().isEmpty) return;
          double n(TextEditingController c) => double.tryParse(c.text.trim()) ?? 0;
          await FirebaseFirestore.instance.collection('currencies').doc(id).set({
            'code': id, 'nameAr': name.text.trim(), 'name': name.text.trim(),
            'officialBuy': n(ob), 'officialSell': n(os), 'parallelBuy': n(pb), 'parallelSell': n(ps),
            'updatedAt': FieldValue.serverTimestamp(), 'updatedBy': adminEmail,
          }, SetOptions(merge: true));
          if (ctx.mounted) Navigator.pop(ctx);
        }, child: const Text('حفظ')),
      ],
    ));
  }
  @override Widget build(BuildContext context) => StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
    stream: FirebaseFirestore.instance.collection('currencies').orderBy('code').snapshots(),
    builder: (context, snapshot) {
      final docs = snapshot.data?.docs ?? [];
      if (snapshot.hasError) return Center(child: Text('خطأ: ${snapshot.error}'));
      return Padding(padding: const EdgeInsets.all(24), child: Column(children: [
        Row(children: [Text('إدارة العملات', style: Theme.of(context).textTheme.headlineSmall), const Spacer(), FilledButton.icon(onPressed: () => edit(context, null), icon: const Icon(Icons.add), label: const Text('إضافة عملة'))]),
        const SizedBox(height: 16),
        Expanded(child: Card(child: ListView.separated(itemCount: docs.length, separatorBuilder: (_, __) => const Divider(height: 1), itemBuilder: (_, i) {
          final doc = docs[i]; final d = doc.data();
          return ListTile(title: Text('${d['nameAr'] ?? d['name'] ?? doc.id} (${doc.id})'), subtitle: Text('رسمي ${d['officialBuy'] ?? 0} / ${d['officialSell'] ?? 0} • موازي ${d['parallelBuy'] ?? 0} / ${d['parallelSell'] ?? 0}'), trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(onPressed: () => edit(context, doc), icon: const Icon(Icons.edit)),
            IconButton(onPressed: () => doc.reference.delete(), icon: const Icon(Icons.delete_outline)),
          ]));
        })))
      ]));
    });
}

class BroadcastPage extends StatefulWidget { const BroadcastPage({super.key}); @override State<BroadcastPage> createState()=>_BroadcastPageState(); }
class _BroadcastPageState extends State<BroadcastPage> {
  final title=TextEditingController(); final body=TextEditingController(); bool loading=false;
  @override void dispose(){title.dispose();body.dispose();super.dispose();}
  Future<void> send() async {
    if(title.text.trim().isEmpty||body.text.trim().isEmpty)return;
    setState(()=>loading=true);
    try{
      final r=await FirebaseFunctions.instance.httpsCallable('sendBroadcastNotification').call({'title':title.text.trim(),'body':body.text.trim()});
      final data=Map<String,dynamic>.from(r.data as Map);
      if(mounted){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تم الإرسال إلى ${data['successCount']??0} جهاز')));title.clear();body.clear();}
    }on FirebaseFunctionsException catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.message??'فشل الإرسال')));}
    finally{if(mounted)setState(()=>loading=false);}
  }
  @override Widget build(BuildContext context)=>Center(child:SizedBox(width:720,child:Card(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisSize:MainAxisSize.min,children:[
    const Icon(Icons.notifications_active,size:64),const SizedBox(height:12),const Text('إرسال إشعار لجميع المستخدمين',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:22),
    TextField(controller:title,decoration:const InputDecoration(labelText:'عنوان الإشعار')),const SizedBox(height:12),TextField(controller:body,minLines:4,maxLines:7,decoration:const InputDecoration(labelText:'الرسالة')),const SizedBox(height:22),
    SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:loading?null:send,icon:const Icon(Icons.send),label:Text(loading?'جارٍ الإرسال...':'إرسال الآن'))),
  ]))));
}

class NotificationLogPage extends StatelessWidget { const NotificationLogPage({super.key}); @override Widget build(BuildContext context)=>StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
  stream:FirebaseFirestore.instance.collection('notifications_log').orderBy('createdAt',descending:true).limit(100).snapshots(),
  builder:(context,snapshot){final docs=snapshot.data?.docs??[];return Padding(padding:const EdgeInsets.all(24),child:Card(child:ListView.separated(itemCount:docs.length,separatorBuilder:(_,__)=>const Divider(height:1),itemBuilder:(_,i){final d=docs[i].data();return ListTile(leading:const Icon(Icons.notifications),title:Text(d['title']?.toString()??''),subtitle:Text(d['body']?.toString()??''),trailing:Text('نجح ${d['successCount']??0}\nفشل ${d['failureCount']??0}'));})));}); }
